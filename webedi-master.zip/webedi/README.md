# webedi

#### 项目介绍
培训考核项目

#### 软件架构
软件架构说明


#### 安装教程

1. 前端
    安装 nodejs （具体自行百度）
	cd Screen
	npm install
	npm run dev
2. 后端
	安装JDK8
	安装Maven
	安装Eclipse
	配置Eclipse的Maven设置（具体自行百度）
3. 数据库
   安装mysql5.7（安装方法自行百度）
   分别创建jobnavi和webedi数据库
   然后分别导入db文件夹下下面的对应的数据库文件

#### 开发环境

1.前端
  VSCode(+VueJs开发Plugin)（Plugin安装方法具体自行百度）
  
2.后端
  Eclipse

3.数据库
  A5M2 或者任意其它一款支持mysql的DB客户端

#### 技术栈

前端
1.vue 2.5
2.vue-router 3.0
3.vuex 3.0
4.element-ui 1.4
5.bootstrap 3.3

后端
1. SpringBoot 1.5.3.RELEASE
2. MyBatis-Plus 2.0.8
3. MyBatis 3.4.4
4. Spring 4.3.8.RELEASE
5. Beetl 2.7.15
6. hibernate-validator 5.3.5.Final
7. Ehcache 3.3.1
8. Kaptcha 2.3.2
9. Fastjson 1.2.31
10. Shiro 1.4.0
11. Druid 1.0.31

1. xxxx
2. xxxx
3. xxxx

#### 参与贡献

1. Fork 本项目
2. 新建 Feat_xxx 分支
3. 提交代码
4. 新建 Pull Request


#### 码云特技

1. 使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2. 码云官方博客 [blog.gitee.com](https://blog.gitee.com)
3. 你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解码云上的优秀开源项目
4. [GVP](https://gitee.com/gvp) 全称是码云最有价值开源项目，是码云综合评定出的优秀开源项目
5. 码云官方提供的使用手册 [http://git.mydoc.io/](http://git.mydoc.io/)
6. 码云封面人物是一档用来展示码云会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)

1.Install node.js
npm install -g cnpm --registry=https://registry.npm.taobao.org

2
#cnpm install -g vue-cli

3
#cnpm install

4
#cnpm run dev
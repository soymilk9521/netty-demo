<template>
  <div id="app">
    <transition name="fade"
		            mode="out-in">
			<router-view></router-view>
		</transition>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
/*#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}*/
#app {
  font-family: 'Shift-JIS', Helvetica, Arial;
}
body{
  margin: auto;
}
</style>
<style lang="scss">
  @import './styles/index.scss'; // 全局自定义的css样式
</style>

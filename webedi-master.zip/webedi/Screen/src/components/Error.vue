<template>
  <section>
    <p>あdfdsf</p>
  </section>
</template>

<script>
export default {
  name: 'hello',
  data () {
    return {
      username: this.$store.state.username
    }
  }
}
</script>


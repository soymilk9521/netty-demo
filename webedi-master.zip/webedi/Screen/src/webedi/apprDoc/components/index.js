export { default as ApprDocDiffTable } from './ApprDocDiffTable';
export { default as ApprDocSalesTable } from './ApprDocSalesTable';
export { default as ClientStaffPopUp } from './ClientStaffPopUp';

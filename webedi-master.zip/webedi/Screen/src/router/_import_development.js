module.exports = file => require('@/webedi/' + file + '.vue')

module.exports = file => () => import('@/webedi/' + file + '.vue')

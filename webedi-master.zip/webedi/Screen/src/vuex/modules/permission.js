import {constantRouterMap,convertMenu } from '@/router/index';


const permission = {
  state: {
    routers: constantRouterMap,
    addRouters: []
  },
  mutations: {
    SET_ROUTERS: (state, routers) => {
      var p_routers = convertMenu(routers);
      state.addRouters = p_routers;
      state.routers = constantRouterMap.concat(p_routers);
    }
  },
  actions: {
  }
};

export default permission;

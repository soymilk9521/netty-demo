package com.tsrs.webedi.modular.system.dao;

import com.tsrs.webedi.modular.system.persistence.model.Order;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

/**
 * <p>
  * 受注HDR情報 Mapper 接口
 * </p>
 *
 * @author jin-qk
 * @since 2018-03-26
 */
public interface OrderDao extends BaseMapper<Order> {
	
	public List<Map<String,Object>> searchForDetail(Pagination page,Map<String, Object> searchCond);
	
	public Map<String,Object> selectOrderInfoForDetail(@Param("order_id") Integer orderId);
	
	public int updateApprDocSt(Map<String,Object> map);

}
package com.tsrs.webedi.modular.system.persistence.dao;

import com.tsrs.webedi.modular.system.persistence.model.Requestapplydtl;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 請求申請DTL情報 Mapper 接口
 * </p>
 *
 * @author tsrs
 * @since 2017-09-03
 */
public interface RequestapplydtlMapper extends BaseMapper<Requestapplydtl> {

}
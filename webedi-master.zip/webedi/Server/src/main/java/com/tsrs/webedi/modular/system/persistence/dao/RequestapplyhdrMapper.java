package com.tsrs.webedi.modular.system.persistence.dao;

import com.tsrs.webedi.modular.system.persistence.model.Requestapplyhdr;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 請求申請HDR情報 Mapper 接口
 * </p>
 *
 * @author tsrs
 * @since 2017-09-03
 */
public interface RequestapplyhdrMapper extends BaseMapper<Requestapplyhdr> {

}
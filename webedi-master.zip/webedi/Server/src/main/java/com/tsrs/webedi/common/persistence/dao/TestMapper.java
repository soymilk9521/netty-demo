package com.tsrs.webedi.common.persistence.dao;

import com.tsrs.webedi.common.persistence.model.Test;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author tsrs
 * @since 2017-06-23
 */
public interface TestMapper extends BaseMapper<Test> {

}
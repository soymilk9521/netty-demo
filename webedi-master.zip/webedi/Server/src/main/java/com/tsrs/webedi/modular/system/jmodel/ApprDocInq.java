package com.tsrs.webedi.modular.system.jmodel;

public class ApprDocInq {
	private String appr_doc_no;
	private String appr_doc_st;
	private String appr_doc_create_k_nm;
	private String appr_doc_create_dt;
	private String appr_doc_dt_from;
	private String appr_doc_dt_to;
	private String emp_no;
	private String emp_nm;
	private String client_no;
	private String client_nm;
	private String pj_cd;
	private String pj_nm;
	private boolean del_flg;
	public String getAppr_doc_no() {
		return appr_doc_no;
	}
	public void setAppr_doc_no(String appr_doc_no) {
		this.appr_doc_no = appr_doc_no;
	}
	public String getAppr_doc_st() {
		return appr_doc_st;
	}
	public void setAppr_doc_st(String appr_doc_st) {
		this.appr_doc_st = appr_doc_st;
	}
	public String getAppr_doc_create_k_nm() {
		return appr_doc_create_k_nm;
	}
	public void setAppr_doc_create_k_nm(String appr_doc_create_k_nm) {
		this.appr_doc_create_k_nm = appr_doc_create_k_nm;
	}
	public String getAppr_doc_create_dt() {
		return appr_doc_create_dt;
	}
	public void setAppr_doc_create_dt(String appr_doc_create_dt) {
		this.appr_doc_create_dt = appr_doc_create_dt;
	}
	public String getAppr_doc_dt_from() {
		return appr_doc_dt_from;
	}
	public void setAppr_doc_dt_from(String appr_doc_dt_from) {
		this.appr_doc_dt_from = appr_doc_dt_from;
	}
	public String getAppr_doc_dt_to() {
		return appr_doc_dt_to;
	}
	public void setAppr_doc_dt_to(String appr_doc_dt_to) {
		this.appr_doc_dt_to = appr_doc_dt_to;
	}
	public String getEmp_no() {
		return emp_no;
	}
	public void setEmp_no(String emp_no) {
		this.emp_no = emp_no;
	}
	public String getEmp_nm() {
		return emp_nm;
	}
	public void setEmp_nm(String emp_nm) {
		this.emp_nm = emp_nm;
	}
	public String getClient_no() {
		return client_no;
	}
	public void setClient_no(String client_no) {
		this.client_no = client_no;
	}
	public String getClient_nm() {
		return client_nm;
	}
	public void setClient_nm(String client_nm) {
		this.client_nm = client_nm;
	}
	public String getPj_cd() {
		return pj_cd;
	}
	public void setPj_cd(String pj_cd) {
		this.pj_cd = pj_cd;
	}
	public String getPj_nm() {
		return pj_nm;
	}
	public void setPj_nm(String pj_nm) {
		this.pj_nm = pj_nm;
	}
	public boolean isDel_flg() {
		return del_flg;
	}
	public void setDel_flg(boolean del_flg) {
		this.del_flg = del_flg;
	}
	
}

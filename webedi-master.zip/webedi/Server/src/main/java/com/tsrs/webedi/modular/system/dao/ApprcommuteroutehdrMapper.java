package com.tsrs.webedi.modular.system.dao;

import com.tsrs.webedi.modular.system.persistence.model.Apprcommuteroutehdr;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 通勤経路Hdr Mapper 接口
 * </p>
 *
 * @author tsrs
 * @since 2017-09-03
 */
public interface ApprcommuteroutehdrMapper extends BaseMapper<Apprcommuteroutehdr> {

}
package com.tsrs.webedi.modular.system.persistence.dao;

import com.tsrs.webedi.modular.system.persistence.model.Bpestreqaccepted;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 承認済見積依頼書 Mapper 接口
 * </p>
 *
 * @author tsrs
 * @since 2017-09-03
 */
public interface BpestreqacceptedMapper extends BaseMapper<Bpestreqaccepted> {

}
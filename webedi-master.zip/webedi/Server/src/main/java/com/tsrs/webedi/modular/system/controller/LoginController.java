package com.tsrs.webedi.modular.system.controller;

import static com.tsrs.webedi.core.support.HttpKit.getIp;

import java.util.Date;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.code.kaptcha.Constants;
import com.tsrs.webedi.common.JsonResult;
import com.tsrs.webedi.common.controller.BaseController;
import com.tsrs.webedi.common.exception.InvalidKaptchaException;
import com.tsrs.webedi.common.persistence.dao.UserMapper;
import com.tsrs.webedi.common.persistence.model.User;
import com.tsrs.webedi.core.log.LogManager;
import com.tsrs.webedi.core.log.factory.LogTaskFactory;
import com.tsrs.webedi.core.shiro.ShiroKit;
import com.tsrs.webedi.core.shiro.ShiroUser;
import com.tsrs.webedi.core.util.ToolUtil;
import com.tsrs.webedi.modular.system.service.IUserService;


/**
 * 登录控制器
 *
 * @author Tsrs-WebEDI
 * @Date 2017年1月10日 下午8:25:24
 */
@RestController
public class LoginController extends BaseController {

	@Autowired
	IUserService userService;

	/**
	 * 点击登录执行的动作
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public JsonResult login(@RequestBody User user) {
		try {
			String username = user.getAccount();
			String password = user.getPassword();

			// 验证验证码是否正确
			if (ToolUtil.getKaptchaOnOff()) {
				String kaptcha = super.getPara("kaptcha").trim();
				String code = (String) super.getSession().getAttribute(Constants.KAPTCHA_SESSION_KEY);
				if (ToolUtil.isEmpty(kaptcha) || !kaptcha.equals(code)) {
					throw new InvalidKaptchaException();
				}
			}

			Subject currentUser = ShiroKit.getSubject();
			UsernamePasswordToken token = new UsernamePasswordToken(username, password.toCharArray());
			token.setRememberMe(true);

			currentUser.login(token);

			ShiroUser shiroUser = ShiroKit.getUser();
			super.getSession().setAttribute("shiroUser", shiroUser);
			super.getSession().setAttribute("username", shiroUser.getAccount());
			User loginUser = userService.getUserInfo(shiroUser.getAccount());
			User lastLoginUser = new User();
		    lastLoginUser.setId(loginUser.getId());
			lastLoginUser.setLastLoginDt(new Date());
			userService.updateById(lastLoginUser);
			LogManager.me().executeLog(LogTaskFactory.loginLog(shiroUser.getId(), getIp()));

			ShiroKit.getSession().setAttribute("sessionFlag", true);

			return new JsonResult(RETURN_CODE_200, shiroUser.name+"はログインしました。", shiroUser);
		} catch (Exception e) {
			return new JsonResult(RETURN_CODE_500, "ユーザーやパスワードは間違いです!!!");
		}
	}

	/**
	 * 退出登录
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.POST)
	public JsonResult logOut() {
		LogManager.me().executeLog(LogTaskFactory.exitLog(ShiroKit.getUser().getId(), getIp()));
		ShiroKit.getSubject().logout();
		return new JsonResult(RETURN_CODE_200, "ログアウトしました!");
	}

	
}

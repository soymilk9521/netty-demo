package com.tsrs.webedi.modular.system.jmodel;

public class EvidenceInfo {
	private Integer display_order; 
	
	private String workEvidence;
	public Integer getDisplay_order() {
		return display_order;
	}
	public void setDisplay_order(Integer display_order) {
		this.display_order = display_order;
	}
	public String getWorkEvidence() {
		return workEvidence;
	}
	public void setWorkEvidence(String workEvidence) {
		this.workEvidence = workEvidence;
	}
	

}

package com.tsrs.webedi.modular.system.dao;

import com.tsrs.webedi.modular.system.persistence.model.Esthdr;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

/**
 * <p>
  * 見積HDR情報 Mapper 接口
 * </p>
 *
 * @author jin-qk
 * @since 2018-03-26
 */
public interface EstDao extends BaseMapper<Esthdr> {
	
	public List<Map<String,Object>> searchForEntry(Pagination page,Map<String, Object> searchCond);
		
	public List<Map<String,Object>> searchForDetail(Pagination page,Map<String, Object> searchCond);
	
	public Map<String,Object> selectEstHdrInfoForInsert(String[] apprDocIdAry);
	
	public List<Map<String,Object>> selectEstDtlInfoForInsert(String[] apprDocIdAry);
	
	public Map<String,Object> selectEstHdrInfoForDetail(@Param("est_hid") Integer estHid);
	
	public List<Map<String,Object>> selectEstDtlInfoForDetail(@Param("est_hid")Integer estHid);
	
	public List<Map<String,Object>> searchForOrderEntry(Pagination page,Map<String, Object> searchCond);

}
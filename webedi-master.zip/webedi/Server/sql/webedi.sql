CREATE DATABASE  IF NOT EXISTS `webedi` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `webedi`;
-- MySQL dump 10.13  Distrib 5.6.19, for Win32 (x86)
--
-- Host: localhost    Database: webedi
-- ------------------------------------------------------
-- Server version	5.6.20-enterprise-commercial-advanced-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appclientcontractevidence`
--

DROP TABLE IF EXISTS `appclientcontractevidence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appclientcontractevidence` (
  `appr_client_contract_evidence_d` int(11) NOT NULL COMMENT 'エビデンスID',
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `display_order` int(11) NOT NULL COMMENT '表示順',
  `work_evidence` varchar(2000) COLLATE utf8_bin DEFAULT NULL COMMENT 'エビデンス',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_client_contract_evidence_d`),
  UNIQUE KEY `clientContractEvidence_uk1` (`appr_doc_id`,`display_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='クライアント契約契約条件エビデンス';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appclientcontractevidence`
--

LOCK TABLES `appclientcontractevidence` WRITE;
/*!40000 ALTER TABLE `appclientcontractevidence` DISABLE KEYS */;
/*!40000 ALTER TABLE `appclientcontractevidence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprapplydtl`
--

DROP TABLE IF EXISTS `apprapplydtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprapplydtl` (
  `appr_apply_did` int(11) NOT NULL AUTO_INCREMENT COMMENT '稟議書申請DID',
  `appr_apply_hid` int(11) NOT NULL COMMENT '稟議書申請HID',
  `display_order` int(11) NOT NULL COMMENT '表示順',
  `accept_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '承認者ID',
  `confirm_st` char(1) COLLATE utf8_bin NOT NULL COMMENT '承認状況:1：未承認\n2：承認済\n3：拒否',
  `con_rej_comment` varchar(500) COLLATE utf8_bin NOT NULL COMMENT '承認(拒否)コメント',
  `con_rej_dt` time DEFAULT NULL COMMENT '承認(拒否)日時',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_apply_did`),
  UNIQUE KEY `apprApplyDtl_u_1` (`appr_apply_hid`,`display_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='稟議書申請DTL情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprapplydtl`
--

LOCK TABLES `apprapplydtl` WRITE;
/*!40000 ALTER TABLE `apprapplydtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprapplydtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprapplyhdr`
--

DROP TABLE IF EXISTS `apprapplyhdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprapplyhdr` (
  `appr_apply_hid` int(11) NOT NULL AUTO_INCREMENT COMMENT '稟議書申請HID',
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN:削除',
  `apply_reason` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '申請理由',
  `apply_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '申請者ID',
  `apply_dt` time NOT NULL COMMENT '申請日時',
  `confirm_wait_display_order` int(11) DEFAULT NULL COMMENT '承認待表示順:承認待となっている申請DTLの表示順を設定',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_apply_hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='稟議書申請HDR情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprapplyhdr`
--

LOCK TABLES `apprapplyhdr` WRITE;
/*!40000 ALTER TABLE `apprapplyhdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprapplyhdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprbpconadr`
--

DROP TABLE IF EXISTS `apprbpconadr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprbpconadr` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `bp_comp_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '所属会社ID',
  `bp_comp_emp_nm` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '所属会社名/社員氏名',
  `bp_comp_url` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社URL',
  `bp_my_number` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社法人マイナンバー',
  `bp_post_no` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社郵便番号',
  `bp_addr` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社連絡先住所',
  `bp_tel_no` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社電話番号',
  `bp_fax_no` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社FAX番号',
  `bp_staff_nm` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社担当者名',
  `bp_staff_nm_fuli` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社担当者名（フリガナ）',
  `bp_staff_dept_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社担当者所属部署',
  `bp_staff_position` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社担当者役職',
  `bp_staff_tel_no` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社担当者電話番号',
  `bp_staff_fax_no` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社担当者FAX番号',
  `bp_staff_mobile_no` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社担当者携帯番号',
  `bp_staff_mobile_mail_addr` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社担当者携帯番号メールアドレス',
  `bp_staff_mail_addr` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社担当者個人メール',
  `bp_staff_mail_addr_cc` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社担当者個人メールCC',
  `staff_addr` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '要員住所',
  `staff_post_no` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '要員郵便番号',
  `staff_mail_addr` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '要員メールアドレス',
  `staff_tel_no` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '要員電話番号',
  `staff_mobile_no` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT '要員携帯電話番号',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='要員（外注BP）連絡先';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprbpconadr`
--

LOCK TABLES `apprbpconadr` WRITE;
/*!40000 ALTER TABLE `apprbpconadr` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprbpconadr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprbpcontract`
--

DROP TABLE IF EXISTS `apprbpcontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprbpcontract` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `working_pj_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '稼働中案件番号',
  `pj_nm` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '作業案件名称',
  `work_place` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '勤務地/最寄駅',
  `work_content` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '作業内容・範囲',
  `cost_price` decimal(10,1) NOT NULL COMMENT '要員渡し/原価',
  `accounting_pat_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '精算条件',
  `wh_max` decimal(4,1) DEFAULT NULL COMMENT '作業時間（上限・H）',
  `wh_min` decimal(4,1) DEFAULT NULL COMMENT '作業時間（下限・H）',
  `wh_mid` decimal(4,1) DEFAULT NULL COMMENT '中割時間',
  `wh_other` decimal(4,1) DEFAULT NULL COMMENT 'その他（時間）',
  `excess_price` decimal(10,1) DEFAULT NULL COMMENT '超過単価（円）',
  `deducation_price` decimal(10,1) DEFAULT NULL COMMENT '控除単価（円）',
  `pj_start_dt` date DEFAULT NULL COMMENT '業務案件今月分の開始日',
  `pj_end_dt` date DEFAULT NULL COMMENT '業務案件今月分の終了日',
  `work_unit_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '作業時間単位',
  `total_work_month` decimal(6,2) NOT NULL COMMENT '工数',
  `hope_job_type_cd` char(3) COLLATE utf8_bin DEFAULT NULL COMMENT '希望職種',
  `pri_exp_job_type_cd` char(3) COLLATE utf8_bin DEFAULT NULL COMMENT '主な経験職種',
  `pj_class_cd` char(3) COLLATE utf8_bin DEFAULT NULL COMMENT '案件分類',
  `work_start_time` time NOT NULL COMMENT '出勤時刻',
  `work_end_time` time NOT NULL COMMENT '退勤時刻',
  `break_time_min` int(11) NOT NULL COMMENT '休憩時間（分）',
  `payment_plan_d` int(11) NOT NULL COMMENT '支払サイト/出金日付の日',
  `payment_due_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '支払サイト/締日区分',
  `pay_month_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '支払サイト/支払月区分',
  `pay_plan_d` int(11) NOT NULL COMMENT '支払サイト/支払日付の日',
  `salary_pay_plan_dt` int(11) NOT NULL COMMENT '支払サイト/出金予定日',
  `work_content_dtl` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '業務内容詳細',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='要員　契約条件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprbpcontract`
--

LOCK TABLES `apprbpcontract` WRITE;
/*!40000 ALTER TABLE `apprbpcontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprbpcontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprclient`
--

DROP TABLE IF EXISTS `apprclient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprclient` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `client_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'クライアント番号',
  `client_nm` varchar(50) COLLATE utf8_bin NOT NULL COMMENT 'クライアント名',
  `client_url` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアントURL',
  `client_my_number` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント法人マイナンバー',
  `client_post_no` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント郵便番号',
  `client_addr` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント連絡先住所',
  `client_tel_no` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント電話番号:XX-XXXX-XXXX',
  `client_fax_no` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアントFAX番号:XX-XXXX-XXXX',
  `client_staff_nm` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント担当者名',
  `client_staff_nm_fuli` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント担当者名（フリガナ）',
  `client_staff_dept_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント担当者所属部署',
  `client_staff_position` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント担当者役職',
  `client_staff_mobile_no` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント担当者携帯番号',
  `client_staff_mobile_mail_addr` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント担当者メールアドレス',
  `client_mail_addr` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアントメール',
  `client_mail_addr_cc` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアントメールCC',
  `client_req_staff_nm` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '請求担当者名',
  `client_req_staff_nm_fuli` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '請求担当者名（フリガナ）',
  `client_req_staff_dept_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '請求担当者所属部署',
  `client_req_staff_position` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '請求担当者役職',
  `client_req_tel_no` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '請求担当者電話番号:XX-XXXX-XXXX',
  `client_req_fax_no` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '請求担当者FAX番号:XX-XXXX-XXXX',
  `client_req_staff_mobile_no` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT '請求担当者携帯番号',
  `client_req_mail_addr` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '請求担当者メール',
  `client_req_mail_addr_cc` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '請求担当者メールCC',
  `client_order_no` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '受注（注文）書No',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='クライアント情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprclient`
--

LOCK TABLES `apprclient` WRITE;
/*!40000 ALTER TABLE `apprclient` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprclient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprclientcontract`
--

DROP TABLE IF EXISTS `apprclientcontract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprclientcontract` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `pj_nm` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業案件名称',
  `work_place` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '勤務地/最寄駅',
  `work_content` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業内容・範囲',
  `accounting_pat_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '精算条件:1：上下割\n2：中割\n3：固定\n4：その他\n ← 記入例：140-200（36-58）/稼働時間200H以内想定',
  `wh_max` decimal(4,1) DEFAULT NULL COMMENT '作業時間（上限・H）',
  `wh_min` decimal(4,1) DEFAULT NULL COMMENT '作業時間（下限・H）',
  `wh_mid` decimal(4,1) DEFAULT NULL COMMENT '中割時間',
  `wh_other` decimal(4,1) DEFAULT NULL COMMENT 'その他（時間）',
  `excess_price` decimal(10,1) DEFAULT NULL COMMENT '超過単価（円）',
  `deducation_price` decimal(10,1) DEFAULT NULL COMMENT '控除単価（円）',
  `pj_start_dt` date DEFAULT NULL COMMENT '業務案件今月分の開始日',
  `pj_end_dt` date DEFAULT NULL COMMENT '業務案件今月分の終了日',
  `work_time_unit_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '作業時間単位',
  `contract_work_month` decimal(6,2) DEFAULT NULL COMMENT '工数（契約用）',
  `pj_class_cd` char(3) COLLATE utf8_bin DEFAULT NULL COMMENT '案件分類',
  `work_start_time` time DEFAULT NULL COMMENT '出勤時刻',
  `work_end_time` time DEFAULT NULL COMMENT '退勤時刻',
  `break_time_min` int(11) DEFAULT NULL COMMENT '休憩時間（分）',
  `payment_plan_d` int(11) DEFAULT NULL COMMENT '支払サイト/出金日付の日',
  `payment_due_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '支払サイト/締日区分',
  `pay_month_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '支払サイト/支払月区分',
  `pay_plan_d` int(11) DEFAULT NULL COMMENT '支払サイト/支払日付の日',
  `salary_pay_plan_dt` int(11) DEFAULT NULL COMMENT '支払サイト/出金予定日',
  `work_content_dtl` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '業務内容詳細',
  `work_evidence1` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT 'エビデンス1',
  `work_evidence2` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT 'エビデンス2',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='クライアント　契約条件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprclientcontract`
--

LOCK TABLES `apprclientcontract` WRITE;
/*!40000 ALTER TABLE `apprclientcontract` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprclientcontract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprcommuteroutedtl`
--

DROP TABLE IF EXISTS `apprcommuteroutedtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprcommuteroutedtl` (
  `appr_commute_route_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '通勤経路ID',
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `from_home_line_nm` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '自宅最寄駅の線',
  `from_home_station_nm` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '自宅最寄駅の駅',
  `to_comp_line_nm` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '現場最寄駅の線',
  `to_comp_station_nm` varchar(30) COLLATE utf8_bin DEFAULT NULL COMMENT '現場最寄駅の駅',
  `travel_cost` decimal(10,1) DEFAULT NULL COMMENT '通勤経路の交通費',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_commute_route_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='通勤経路Dtl';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprcommuteroutedtl`
--

LOCK TABLES `apprcommuteroutedtl` WRITE;
/*!40000 ALTER TABLE `apprcommuteroutedtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprcommuteroutedtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprcommuteroutehdr`
--

DROP TABLE IF EXISTS `apprcommuteroutehdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprcommuteroutehdr` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `day_travel_cost` decimal(10,1) DEFAULT NULL COMMENT '交通費日額（往復）',
  `month_pass_travel_cost` decimal(10,1) DEFAULT NULL COMMENT '1ヶ月の通勤代（定期）',
  `pay_travel_costa_max` decimal(10,1) DEFAULT NULL COMMENT '支払上限',
  `rount_dlt_content` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '自宅→現場（乗り換え含め交通経路記入）',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='通勤経路Hdr';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprcommuteroutehdr`
--

LOCK TABLES `apprcommuteroutehdr` WRITE;
/*!40000 ALTER TABLE `apprcommuteroutehdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprcommuteroutehdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprdoc`
--

DROP TABLE IF EXISTS `apprdoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprdoc` (
  `appr_doc_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '稟議書ID',
  `appr_doc_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '稟議書NO',
  `appr_doc_dt_from` date NOT NULL COMMENT '対象期間From',
  `appr_doc_dt_to` date NOT NULL COMMENT '対象期間To',
  `appr_doc_create_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '稟議書作成区分:1：通常更新\n2：新規\n3：条件変更\n4：正社員化\n5：退職\n6：再販',
  `appr_doc_create_dt` date NOT NULL COMMENT '稟議書作成日',
  `appr_doc_st` char(1) COLLATE utf8_bin NOT NULL COMMENT '稟議書状態:1：申請待    稟議書データ登録直後\n2：承認待    稟議書データ承認WFを申請後　※申請後、承認中前、申請取消が可能\n3：承認中    稟議書承認WFがスタート後\n4：承認済    承認経路の承認者がすべて承認済、\n5：契約済    受注先と合意済の後\nA:取消     ユーザー取消（画面上で検索可能）',
  `business_main_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '営業主担当',
  `business_sub_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '副担当',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN:削除',
  `business_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '営業コメント',
  `purchase_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '購買コメント',
  `other_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT 'その他コメント',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`),
  UNIQUE KEY `apprDoc_i_alt1` (`appr_doc_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='稟議書';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprdoc`
--

LOCK TABLES `apprdoc` WRITE;
/*!40000 ALTER TABLE `apprdoc` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprdoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprdocaccepted`
--

DROP TABLE IF EXISTS `apprdocaccepted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprdocaccepted` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `last_accept_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '最終承認者ID',
  `last_accept_date` datetime NOT NULL COMMENT '最終承認日時',
  `approval_apply_hid` int(11) NOT NULL COMMENT '稟議書申請HID',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='承認済稟議書';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprdocaccepted`
--

LOCK TABLES `apprdocaccepted` WRITE;
/*!40000 ALTER TABLE `apprdocaccepted` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprdocaccepted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appremp`
--

DROP TABLE IF EXISTS `appremp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appremp` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `emp_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '社員番号',
  `emp_nm` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '社員名',
  `emp_nm_fuli` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '社員名（フリガナ）',
  `emp_sex` char(1) COLLATE utf8_bin NOT NULL COMMENT '性別:M：男\nF：女',
  `emp_birthday` char(1) COLLATE utf8_bin NOT NULL COMMENT '生年月日',
  `entrance_dt` date NOT NULL COMMENT '入社日',
  `emp_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '要員区分:1：新規要員\n2：既存要員\n3：要員退社',
  `emp_my_number` varchar(20) COLLATE utf8_bin DEFAULT NULL COMMENT '要員マイナンバー',
  `emp_pat_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '希望雇用形態:1：正社員\n2：契約社員\n3：個人事業主\n4：外注\n9：その他',
  `emp_contract_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '要員契約区分:1：準委任契約\n2：派遣契約\n3：雇用契約',
  `affiliation_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '所属区分:1：自社プロパー\n2：BP社',
  `emp_other_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT 'その他区分:1：準委任契約\n2：派遣契約\n3：雇用契約',
  `bp_contract_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT 'BP契約区分:1：準委任契約\n2：派遣契約\n3：雇用契約',
  `entrance_record_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '入社経歴:1：有\n2：無',
  `old_appr_doc_no` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '前回稟議書NO',
  `insurance_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '保険加入:1：雇用保険のみ\n2：社保険完備\n3：保険無し',
  `take_over_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '引取区分:1：新規取引先\n2：既存取引先',
  `contract_form_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '契約形態:1：委任（ＳＥＳ）\n2：派遣契約',
  `order_recv_hope_dt` date DEFAULT NULL COMMENT '注文書受領日（見込）',
  `from_home_station_nm` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '最寄駅（自宅）',
  `client_contract_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '契約（上位）:1：委任契約\n2：派遣契約',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='要員入場者';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appremp`
--

LOCK TABLES `appremp` WRITE;
/*!40000 ALTER TABLE `appremp` DISABLE KEYS */;
/*!40000 ALTER TABLE `appremp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprempallowanceratio`
--

DROP TABLE IF EXISTS `apprempallowanceratio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprempallowanceratio` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `appoint_allow_ratio` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '役職手当割合',
  `house_allow_ratio` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '住宅手当割合',
  `aliment_allow_ratio` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '扶養手当割合',
  `communication_allow_ratio` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '通信手当割合',
  `site_allow_ratio` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '現場手当割合',
  `duty_allow_ratio` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '当番手当割合',
  `overwork_allow_ratio` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '残業手当割合',
  `qualification_allow_ratio` decimal(5,2) NOT NULL DEFAULT '0.00' COMMENT '資格手当割合',
  `other_allow1_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT 'そのた手当1名称',
  `other_allow1_ratio` decimal(5,2) DEFAULT '0.00' COMMENT 'そのた手当1割合',
  `other_allow2_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT 'そのた手当1名称',
  `other_allow2_ratio` decimal(5,2) DEFAULT '0.00' COMMENT 'そのた手当２割合',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='要員月額手当割合';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprempallowanceratio`
--

LOCK TABLES `apprempallowanceratio` WRITE;
/*!40000 ALTER TABLE `apprempallowanceratio` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprempallowanceratio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprmonproset`
--

DROP TABLE IF EXISTS `apprmonproset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprmonproset` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `mon_pro_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '月次処理区分:1：通常締結\n2：EDI',
  `work_rep_f` char(1) COLLATE utf8_bin NOT NULL COMMENT '作業報告書F:1：指定なし\n2：客先F',
  `bill_f` char(1) COLLATE utf8_bin NOT NULL COMMENT '請求書F:1：指定なし\n2：客先F',
  `work_rep_dl_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '作業報告書締め区分:1：指定なし\n2：第1営業日　　　＃＃時\n3：第2営業日　　　＃＃時\n4：第3営業日　　　＃＃時\n5：第4-5営業日　＃＃時',
  `bill_dl_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '請求書締め区分:1：指定なし\n2：第1営業日　　　＃＃時\n3：第2営業日　　　＃＃時\n4：第3営業日　　　＃＃時\n5：第4-5営業日　＃＃時',
  `mon_attach_file_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '添付資料F:1：有\n2：無',
  `mon_attach_file_id` int(11) DEFAULT NULL COMMENT '添付ファイルID',
  `mon_remark` varchar(1000) COLLATE utf8_bin DEFAULT NULL COMMENT '補足事項',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='月次処理設定';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprmonproset`
--

LOCK TABLES `apprmonproset` WRITE;
/*!40000 ALTER TABLE `apprmonproset` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprmonproset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprpurchaserequestcontent`
--

DROP TABLE IF EXISTS `apprpurchaserequestcontent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprpurchaserequestcontent` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `contract_pat_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '契約形態:1：BP会社\n2：フリー\n3：契約社員\n4：正社員',
  `procedure_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '手続き区分:1：新規入社処理\n2：契約期間更新処理\n3：退社処理',
  `procedure_method_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '手続き方法',
  `withdrawal_reason_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '退社理由',
  `withdrawal_letter_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '離職票の有無',
  `insurance_con_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '社保任意継続',
  `withdrawal_req_doc` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '必要書類',
  `procedure_dt` date DEFAULT NULL COMMENT '手続き日付',
  `withdrawal_dt` date DEFAULT NULL COMMENT '退社日',
  `after_withdrawal_post_no` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '退社後郵便番号',
  `after_withdrawal_addr` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '退社後住所',
  `purchase_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '連絡事項（購買へ）',
  `commercial_dist_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '商流記載',
  `emp_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '特記事項（要員）',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='購買の依頼内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprpurchaserequestcontent`
--

LOCK TABLES `apprpurchaserequestcontent` WRITE;
/*!40000 ALTER TABLE `apprpurchaserequestcontent` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprpurchaserequestcontent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apprsalesgrossprofitdtl`
--

DROP TABLE IF EXISTS `apprsalesgrossprofitdtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `apprsalesgrossprofitdtl` (
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `sales_addup_month` int(11) NOT NULL COMMENT '売上販売計上月:1～12\n売上販売の計上月\n（請求対象月ではない）',
  `work_days` int(11) NOT NULL COMMENT '当月稼働日:1～31',
  `billing_month` int(11) NOT NULL COMMENT '請求計上月:1～12',
  `sell_price` decimal(10,1) NOT NULL COMMENT '上位単金/単価',
  `business_days` int(11) NOT NULL COMMENT '当月営業日:1～31',
  `cost_price` decimal(10,1) NOT NULL COMMENT '要員渡し/原価',
  `sell_price_tax_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '単価消費税区分:1：税込\n2：税抜',
  `cost_price_tax_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '原価消費税区分:1：税込\n2：税抜',
  `travel_cost_first_mon` decimal(10,1) NOT NULL COMMENT '交通費(初月)',
  `other_cost_first_mon` decimal(10,1) NOT NULL COMMENT 'その他(初月)',
  `travel_cost` decimal(10,1) NOT NULL COMMENT '交通費',
  `insurance_cost` decimal(10,1) DEFAULT NULL COMMENT '社保費',
  `other_cost` decimal(10,1) NOT NULL COMMENT 'その他',
  `insurance_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '社保区分:1:（業務委託契約のため、対象外）\n2：(入社2ヶ月後加入)\n3：(入社翌月から加入）\n4：(入社日から加入）',
  `insurance_join_y` char(4) COLLATE utf8_bin DEFAULT NULL COMMENT '社保加入年:yyyy',
  `insurance_join_ym` char(2) COLLATE utf8_bin DEFAULT NULL COMMENT '社保加入月:mm',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`appr_doc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='売上/粗利・明細';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apprsalesgrossprofitdtl`
--

LOCK TABLES `apprsalesgrossprofitdtl` WRITE;
/*!40000 ALTER TABLE `apprsalesgrossprofitdtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `apprsalesgrossprofitdtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `basepricemgr`
--

DROP TABLE IF EXISTS `basepricemgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `basepricemgr` (
  `base_price_mgr_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '標準報酬管理ID',
  `base_price_type` char(1) COLLATE utf8_bin NOT NULL COMMENT '標準報酬タイプ:1：健康保険\n2：厚生年金',
  `start_dt` date NOT NULL COMMENT '開始日',
  `end_dt` date NOT NULL COMMENT '終了日:‘2099/12/31’',
  `salary_from` decimal(10,1) NOT NULL COMMENT '報酬月額From',
  `salary_to` decimal(10,1) NOT NULL DEFAULT '999.0' COMMENT '報酬月額To(含まれまい)',
  `base_price` decimal(10,1) NOT NULL COMMENT '標準報酬',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`base_price_mgr_id`),
  UNIQUE KEY `ratioMgr_u_atl1` (`base_price_type`,`salary_from`,`salary_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='標準報酬管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `basepricemgr`
--

LOCK TABLES `basepricemgr` WRITE;
/*!40000 ALTER TABLE `basepricemgr` DISABLE KEYS */;
/*!40000 ALTER TABLE `basepricemgr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bpestdtl`
--

DROP TABLE IF EXISTS `bpestdtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpestdtl` (
  `bp_est_did` int(11) NOT NULL AUTO_INCREMENT COMMENT 'BP見積DID',
  `bp_est_hid` int(11) NOT NULL COMMENT 'BP見積HID',
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`bp_est_did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='BP見積DTL情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpestdtl`
--

LOCK TABLES `bpestdtl` WRITE;
/*!40000 ALTER TABLE `bpestdtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `bpestdtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bpesthdr`
--

DROP TABLE IF EXISTS `bpesthdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpesthdr` (
  `bp_est_hid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'BP見積ID',
  `bp_est_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'BP見積NO',
  `bp_est_request_no` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT 'BP見積依頼NO',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y/N',
  `bp_est_amt_without_tax` decimal(13,1) NOT NULL COMMENT '見積金額(税抜)',
  `work_start_ymd` date NOT NULL COMMENT '作業開始日',
  `work_end_ymd` date NOT NULL COMMENT '作業終了日',
  `project_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '案件番号',
  `project_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '案件名称',
  `work_content` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業内容',
  `work_place` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '作業場所',
  `bp_est_content` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '見積内容',
  `special_affairs` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '特記事項',
  `remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '備考',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`bp_est_hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='BP見積HDR情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpesthdr`
--

LOCK TABLES `bpesthdr` WRITE;
/*!40000 ALTER TABLE `bpesthdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `bpesthdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bpestrecv`
--

DROP TABLE IF EXISTS `bpestrecv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpestrecv` (
  `bp_est_recv_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'BP見積受信ID',
  `recv_dt` datetime NOT NULL COMMENT '受信日時',
  `bp_est_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'BP見積NO',
  `bp_est_req_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'BP見積依頼NO',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y/N',
  `bp_est_amt_without_tax` decimal(13,1) NOT NULL COMMENT '見積金額(税抜)',
  `work_start_ymd` date NOT NULL COMMENT '作業開始日',
  `work_end_ymd` date NOT NULL COMMENT '作業終了日',
  `project_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '案件番号',
  `project_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '案件名称',
  `work_content` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業内容',
  `work_place` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '作業場所',
  `bp_est_content` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '見積内容',
  `special_affairs` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '特記事項',
  `remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '備考',
  `appr_doc_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '稟議書NO',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`bp_est_recv_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='BP見積受信情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpestrecv`
--

LOCK TABLES `bpestrecv` WRITE;
/*!40000 ALTER TABLE `bpestrecv` DISABLE KEYS */;
/*!40000 ALTER TABLE `bpestrecv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bpestreqaccepted`
--

DROP TABLE IF EXISTS `bpestreqaccepted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpestreqaccepted` (
  `bp_est_req_id` int(11) NOT NULL COMMENT 'BP見積依頼HID',
  `last_accept_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '最終承認者ID',
  `last_accept_date` datetime NOT NULL COMMENT '最終承認日時',
  `bp_est_req_apply_hid` int(11) NOT NULL COMMENT 'BP見積依頼申請HID',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`bp_est_req_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='承認済見積依頼書';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpestreqaccepted`
--

LOCK TABLES `bpestreqaccepted` WRITE;
/*!40000 ALTER TABLE `bpestreqaccepted` DISABLE KEYS */;
/*!40000 ALTER TABLE `bpestreqaccepted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bpestreqapplydtl`
--

DROP TABLE IF EXISTS `bpestreqapplydtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpestreqapplydtl` (
  `bp_est_req_apply_did` int(11) NOT NULL AUTO_INCREMENT COMMENT 'BP見積依頼申請DID',
  `bp_est_req_apply_hid` int(11) NOT NULL COMMENT 'BP見積依頼申請HID',
  `display_order` int(11) NOT NULL COMMENT '表示順',
  `accept_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '承認者ID',
  `confirm_st` char(1) COLLATE utf8_bin NOT NULL COMMENT '承認状況:1：未承認\n2：承認済\n3：拒否',
  `con_rej_comment` varchar(500) COLLATE utf8_bin NOT NULL COMMENT '承認(拒否)コメント',
  `con_rej_dt` time DEFAULT NULL COMMENT '承認(拒否)日時',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`bp_est_req_apply_did`),
  UNIQUE KEY `bpEstReqApplyDtl_u_1` (`bp_est_req_apply_hid`,`display_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='BP見積依頼申請DTL情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpestreqapplydtl`
--

LOCK TABLES `bpestreqapplydtl` WRITE;
/*!40000 ALTER TABLE `bpestreqapplydtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `bpestreqapplydtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bpestreqapplyhdr`
--

DROP TABLE IF EXISTS `bpestreqapplyhdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpestreqapplyhdr` (
  `bp_est_req_apply_hid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'BP見積依頼申請HID',
  `bp_est_req_id` int(11) NOT NULL COMMENT 'BP見積依頼ID',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN:削除',
  `apply_reason` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '申請理由',
  `apply_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '申請者ID',
  `apply_dt` time NOT NULL COMMENT '申請日時',
  `confirm_wait_display_order` int(11) DEFAULT NULL COMMENT '承認待表示順:承認待となっている申請DTLの表示順を設定',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`bp_est_req_apply_hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='BP見積依頼申請HDR情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpestreqapplyhdr`
--

LOCK TABLES `bpestreqapplyhdr` WRITE;
/*!40000 ALTER TABLE `bpestreqapplyhdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `bpestreqapplyhdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bpestreqdtl`
--

DROP TABLE IF EXISTS `bpestreqdtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpestreqdtl` (
  `bp_est_req_did` int(11) NOT NULL AUTO_INCREMENT COMMENT 'BP見積依頼DID',
  `bp_est_req_hid` int(11) NOT NULL COMMENT 'BP見積依頼HID',
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`bp_est_req_did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='BP見積依頼DTL情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpestreqdtl`
--

LOCK TABLES `bpestreqdtl` WRITE;
/*!40000 ALTER TABLE `bpestreqdtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `bpestreqdtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bpestreqhdr`
--

DROP TABLE IF EXISTS `bpestreqhdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpestreqhdr` (
  `bp_est_req_hid` int(11) NOT NULL AUTO_INCREMENT COMMENT 'BP見積依頼HID',
  `bp_est_req_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'BP見積依頼NO',
  `bp_order_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'BP受注NO',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y/N',
  `order_hid` int(11) NOT NULL COMMENT '受注HID',
  `bp_est_hope_amt_without_tax` decimal(13,1) NOT NULL COMMENT '見積希望金額(税抜)',
  `work_start_ymd` date NOT NULL COMMENT '作業開始日',
  `work_end_ymd` date NOT NULL COMMENT '作業終了日',
  `project_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '案件番号',
  `project_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '案件名称',
  `work_content` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業内容',
  `work_place` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '作業場所',
  `bp_est_req_content` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '見積依頼内容',
  `order_special_affairs` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '特記事項',
  `order_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '備考',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`bp_est_req_hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='BP見積依頼HDR情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpestreqhdr`
--

LOCK TABLES `bpestreqhdr` WRITE;
/*!40000 ALTER TABLE `bpestreqhdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `bpestreqhdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bpestreqsend`
--

DROP TABLE IF EXISTS `bpestreqsend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpestreqsend` (
  `bp_est_req_send_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'BP見積依頼送信ID',
  `send_dt` datetime NOT NULL COMMENT '送信日時',
  `bp_est_req_id` int(11) NOT NULL COMMENT 'BP見積依頼ID',
  `bp_est_req_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'BP見積依頼NO',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y/N',
  `bp_est_hope_amt_without_tax` decimal(13,1) NOT NULL COMMENT '見積希望金額(税抜)',
  `work_start_ymd` date NOT NULL COMMENT '作業開始日',
  `work_end_ymd` date NOT NULL COMMENT '作業終了日',
  `project_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '案件番号',
  `project_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '案件名称',
  `work_content` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業内容',
  `work_place` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '作業場所',
  `bp_est_req_content` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '見積依頼内容',
  `order_special_affairs` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '特記事項',
  `order_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '備考',
  `appr_doc_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '稟議書NO',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`bp_est_req_send_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='BP見積依頼送信情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpestreqsend`
--

LOCK TABLES `bpestreqsend` WRITE;
/*!40000 ALTER TABLE `bpestreqsend` DISABLE KEYS */;
/*!40000 ALTER TABLE `bpestreqsend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bpshippingorder`
--

DROP TABLE IF EXISTS `bpshippingorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bpshippingorder` (
  `bp_shipping_order_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'BP発注ID',
  `bp_shipping_order_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'BP発注NO',
  `bp_estimation_id` int(11) NOT NULL COMMENT 'BP見積ID',
  `bp_estimation_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'BP見積NO',
  `bp_estimation_request_id` int(11) DEFAULT NULL COMMENT 'BP見積依頼ID',
  `bp_estimation_request_no` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT 'BP見積依頼NO',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y/N',
  `order_hid` int(11) NOT NULL COMMENT '受注HID',
  `order_amt_without_tax` decimal(13,1) NOT NULL COMMENT '受注金額(税抜)',
  `work_start_ymd` date NOT NULL COMMENT '作業開始日',
  `work_end_ymd` date NOT NULL COMMENT '作業終了日',
  `project_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '案件番号',
  `project_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '案件名称',
  `work_content` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業内容',
  `work_place` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '作業場所',
  `order_content` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '注文内容',
  `order_special_affairs` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '特記事項',
  `order_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '備考',
  `order_doc_file_id` int(11) DEFAULT NULL COMMENT '注文書',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`bp_shipping_order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='BP発注情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bpshippingorder`
--

LOCK TABLES `bpshippingorder` WRITE;
/*!40000 ALTER TABLE `bpshippingorder` DISABLE KEYS */;
/*!40000 ALTER TABLE `bpshippingorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendar`
--

DROP TABLE IF EXISTS `calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calendar` (
  `calendar_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'カレンダーID',
  `ym` date NOT NULL COMMENT '年月',
  `ymd` date NOT NULL COMMENT '年月日',
  `calendar_k` char(1) COLLATE utf8_bin NOT NULL COMMENT 'カレンダー区分:1:稼働日\n2:週末\n3:祝日',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`calendar_id`),
  KEY `calendar_i_1` (`ym`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='カレンダー';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar`
--

LOCK TABLES `calendar` WRITE;
/*!40000 ALTER TABLE `calendar` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dept`
--

DROP TABLE IF EXISTS `dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dept` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'キーid',
  `num` int(11) DEFAULT NULL COMMENT '順番',
  `pid` int(11) DEFAULT NULL COMMENT '親部門id',
  `simplename` varchar(45) DEFAULT NULL COMMENT '略称',
  `fullname` varchar(255) DEFAULT NULL COMMENT 'フルネーム',
  `tips` varchar(255) DEFAULT NULL COMMENT 'ヒント',
  `version` int(11) DEFAULT NULL COMMENT 'バージョン',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8 COMMENT='部門表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dept`
--

LOCK TABLES `dept` WRITE;
/*!40000 ALTER TABLE `dept` DISABLE KEYS */;
INSERT INTO `dept` VALUES (25,2,24,'開発部','開発部','',NULL),(26,3,24,'運営部','運営部','',NULL),(27,4,24,'戦略部','戦略部','',NULL),(28,5,1,'测试','测试fullname','测试tips',1),(29,5,1,'测试','测试fullname','测试tips',1),(30,5,1,'测试','测试fullname','测试tips',1),(31,5,1,'测试','测试fullname','测试tips',1),(32,5,1,'测试','测试fullname','测试tips',1),(33,5,1,'测试','测试fullname','测试tips',1),(34,5,1,'测试','测试fullname','测试tips',1),(35,5,1,'测试','测试fullname','测试tips',1),(36,5,1,'测试','测试fullname','测试tips',1),(37,5,1,'测试','测试fullname','测试tips',1),(38,5,1,'测试','测试fullname','测试tips',1);
/*!40000 ALTER TABLE `dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dict`
--

DROP TABLE IF EXISTS `dict`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dict` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'キーid',
  `num` int(11) DEFAULT NULL COMMENT '順番',
  `pid` int(11) DEFAULT NULL COMMENT '親辞書',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `tips` varchar(255) DEFAULT NULL COMMENT 'ヒント',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8 COMMENT='辞書表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dict`
--

LOCK TABLES `dict` WRITE;
/*!40000 ALTER TABLE `dict` DISABLE KEYS */;
INSERT INTO `dict` VALUES (29,0,0,'性別',NULL),(30,1,29,'男',NULL),(31,2,29,'女',NULL),(35,0,0,'アカウント状態',NULL),(36,1,35,'起用',NULL),(37,2,35,'凍結',NULL),(38,3,35,'削除済み',NULL),(39,0,0,'这是一个字典测试',NULL),(40,1,39,'测试1',NULL),(41,2,39,'测试2',NULL),(42,0,0,'测试',NULL),(43,1,42,'测试1',NULL),(44,2,42,'测试2',NULL);
/*!40000 ALTER TABLE `dict` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estdtl`
--

DROP TABLE IF EXISTS `estdtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estdtl` (
  `est_did` int(11) NOT NULL AUTO_INCREMENT COMMENT '見積DID',
  `est_hid` int(11) NOT NULL COMMENT '見積HID',
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`est_did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='見積DTL情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estdtl`
--

LOCK TABLES `estdtl` WRITE;
/*!40000 ALTER TABLE `estdtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `estdtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `esthdr`
--

DROP TABLE IF EXISTS `esthdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `esthdr` (
  `est_hid` int(11) NOT NULL AUTO_INCREMENT COMMENT '見積HID',
  `est_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '見積NO',
  `shipping_order_spec_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '発注仕様書NO',
  `submit_dt` date NOT NULL COMMENT '提出日',
  `client_nm` varchar(50) COLLATE utf8_bin NOT NULL COMMENT 'クライアント名',
  `estimation_amt_without_tax` decimal(13,1) NOT NULL COMMENT '見積金額(税抜)',
  `work_start_ymd` date NOT NULL COMMENT '作業開始日',
  `work_end_ymd` date NOT NULL COMMENT '作業終了日',
  `project_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '案件番号',
  `project_nm` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '案件名称',
  `work_content` varchar(200) COLLATE utf8_bin NOT NULL COMMENT '作業内容',
  `work_place` varchar(100) COLLATE utf8_bin NOT NULL COMMENT '作業場所',
  `order_content` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '注文内容',
  `special_affairs` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '特記事項',
  `payment_cond` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT 'お支払条件',
  `remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '備考',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`est_hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='見積HDR情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `esthdr`
--

LOCK TABLES `esthdr` WRITE;
/*!40000 ALTER TABLE `esthdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `esthdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobtitle`
--

DROP TABLE IF EXISTS `jobtitle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobtitle` (
  `job_title_cd` char(3) COLLATE utf8_bin NOT NULL COMMENT '職位C',
  `job_tile_nm` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '職位名称',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN：廃止',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`job_title_cd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='職位';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobtitle`
--

LOCK TABLES `jobtitle` WRITE;
/*!40000 ALTER TABLE `jobtitle` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobtitle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobtype`
--

DROP TABLE IF EXISTS `jobtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobtype` (
  `job_type_cd` char(3) COLLATE utf8_bin NOT NULL COMMENT '職種C',
  `job_type_nm` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '職種名称',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN：廃止',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`job_type_cd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='職種';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobtype`
--

LOCK TABLES `jobtype` WRITE;
/*!40000 ALTER TABLE `jobtype` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_log`
--

DROP TABLE IF EXISTS `login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_log` (
  `id` int(65) NOT NULL AUTO_INCREMENT COMMENT 'キー',
  `logname` varchar(255) DEFAULT NULL COMMENT 'ログ名称',
  `userid` int(65) DEFAULT NULL COMMENT '管理者id',
  `createtime` datetime DEFAULT NULL COMMENT '作成時間',
  `succeed` varchar(255) DEFAULT NULL COMMENT '実行成功',
  `message` text COMMENT '詳細情報',
  `ip` varchar(255) DEFAULT NULL COMMENT '登録ip',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=282 DEFAULT CHARSET=utf8 COMMENT='登録ログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_log`
--

LOCK TABLES `login_log` WRITE;
/*!40000 ALTER TABLE `login_log` DISABLE KEYS */;
INSERT INTO `login_log` VALUES (126,'ログアウトログ',1,'2017-06-04 10:21:55','成功',NULL,'127.0.0.1'),(127,'登録ログ',1,'2017-06-04 10:21:59','成功',NULL,'127.0.0.1'),(128,'ログアウトログ',1,'2017-06-04 10:22:59','成功',NULL,'127.0.0.1'),(129,'登録ログ',1,'2017-06-04 10:23:01','成功',NULL,'127.0.0.1'),(130,'登录日志',1,'2017-07-03 21:02:28','成功',NULL,'0:0:0:0:0:0:0:1'),(131,'退出日志',1,'2017-07-03 21:18:35','成功',NULL,'0:0:0:0:0:0:0:1'),(132,'登录日志',1,'2017-07-03 21:32:58','成功',NULL,'0:0:0:0:0:0:0:1'),(133,'退出日志',1,'2017-07-03 21:36:33','成功',NULL,'0:0:0:0:0:0:0:1'),(134,'登录日志',1,'2017-07-03 21:36:41','成功',NULL,'0:0:0:0:0:0:0:1'),(135,'退出日志',1,'2017-07-03 21:57:09','成功',NULL,'0:0:0:0:0:0:0:1'),(136,'登录日志',1,'2017-07-03 21:57:18','成功',NULL,'0:0:0:0:0:0:0:1'),(137,'退出日志',1,'2017-07-03 21:59:40','成功',NULL,'0:0:0:0:0:0:0:1'),(138,'登录日志',1,'2017-07-03 22:00:40','成功',NULL,'0:0:0:0:0:0:0:1'),(139,'退出日志',1,'2017-07-03 22:02:05','成功',NULL,'0:0:0:0:0:0:0:1'),(140,'登录日志',1,'2017-07-03 22:02:15','成功',NULL,'0:0:0:0:0:0:0:1'),(141,'退出日志',1,'2017-07-03 22:03:26','成功',NULL,'0:0:0:0:0:0:0:1'),(142,'登录日志',1,'2017-07-03 22:05:23','成功',NULL,'0:0:0:0:0:0:0:1'),(143,'退出日志',1,'2017-07-04 20:00:57','成功',NULL,'0:0:0:0:0:0:0:1'),(144,'登录日志',1,'2017-07-04 20:01:06','成功',NULL,'0:0:0:0:0:0:0:1'),(145,'退出日志',1,'2017-07-05 21:47:13','成功',NULL,'0:0:0:0:0:0:0:1'),(146,'登录日志',1,'2017-07-05 22:29:18','成功',NULL,'0:0:0:0:0:0:0:1'),(147,'退出日志',1,'2017-07-06 20:34:12','成功',NULL,'0:0:0:0:0:0:0:1'),(148,'登录日志',1,'2017-07-06 20:35:06','成功',NULL,'0:0:0:0:0:0:0:1'),(149,'登录日志',1,'2017-07-07 21:47:34','成功',NULL,'0:0:0:0:0:0:0:1'),(150,'登录日志',1,'2017-07-17 22:16:18','成功',NULL,'0:0:0:0:0:0:0:1'),(151,'登录日志',1,'2017-07-17 22:27:42','成功',NULL,'127.0.0.1'),(152,'登录日志',1,'2017-07-17 22:34:28','成功',NULL,'127.0.0.1'),(153,'登录日志',1,'2017-07-17 22:40:29','成功',NULL,'127.0.0.1'),(154,'登录日志',1,'2017-07-17 22:59:19','成功',NULL,'127.0.0.1'),(155,'登录日志',1,'2017-07-17 23:12:11','成功',NULL,'127.0.0.1'),(156,'登录日志',1,'2017-07-19 21:05:03','成功',NULL,'127.0.0.1'),(157,'登录日志',1,'2017-07-23 15:25:40','成功',NULL,'127.0.0.1'),(158,'登录日志',1,'2017-07-23 15:29:03','成功',NULL,'127.0.0.1'),(159,'登录日志',1,'2017-07-23 15:39:22','成功',NULL,'127.0.0.1'),(160,'登录日志',1,'2017-07-23 15:41:21','成功',NULL,'127.0.0.1'),(161,'登录日志',1,'2017-07-23 15:43:54','成功',NULL,'127.0.0.1'),(162,'退出日志',1,'2017-07-23 15:50:26','成功',NULL,'127.0.0.1'),(163,'登录日志',1,'2017-07-23 15:55:06','成功',NULL,'127.0.0.1'),(164,'退出日志',1,'2017-07-23 15:55:19','成功',NULL,'127.0.0.1'),(165,'登录日志',1,'2017-07-23 15:59:15','成功',NULL,'127.0.0.1'),(166,'退出日志',1,'2017-07-23 15:59:25','成功',NULL,'127.0.0.1'),(167,'登录日志',1,'2017-07-23 16:02:57','成功',NULL,'127.0.0.1'),(168,'退出日志',1,'2017-07-23 16:03:07','成功',NULL,'127.0.0.1'),(169,'登录日志',1,'2017-07-23 16:05:27','成功',NULL,'127.0.0.1'),(170,'退出日志',1,'2017-07-23 16:05:33','成功',NULL,'127.0.0.1'),(171,'登录日志',1,'2017-07-23 16:07:46','成功',NULL,'127.0.0.1'),(172,'退出日志',1,'2017-07-23 16:07:53','成功',NULL,'127.0.0.1'),(173,'登录日志',1,'2017-07-23 16:08:45','成功',NULL,'127.0.0.1'),(174,'退出日志',1,'2017-07-23 16:08:52','成功',NULL,'127.0.0.1'),(175,'登录日志',1,'2017-07-23 16:34:34','成功',NULL,'127.0.0.1'),(176,'退出日志',1,'2017-07-23 19:39:32','成功',NULL,'127.0.0.1'),(177,'登录日志',1,'2017-07-23 19:39:51','成功',NULL,'127.0.0.1'),(178,'登录日志',1,'2017-07-23 20:18:42','成功',NULL,'127.0.0.1'),(179,'登录日志',1,'2017-07-23 22:29:28','成功',NULL,'127.0.0.1'),(180,'登录日志',1,'2017-07-23 22:30:06','成功',NULL,'127.0.0.1'),(181,'登录日志',1,'2017-07-23 22:30:25','成功',NULL,'127.0.0.1'),(182,'登录日志',1,'2017-07-23 22:32:29','成功',NULL,'127.0.0.1'),(183,'登录日志',1,'2017-07-23 22:33:49','成功',NULL,'127.0.0.1'),(184,'登录日志',1,'2017-07-23 22:34:07','成功',NULL,'127.0.0.1'),(185,'登录日志',1,'2017-07-23 22:35:55','成功',NULL,'127.0.0.1'),(186,'登录日志',1,'2017-07-23 22:38:57','成功',NULL,'127.0.0.1'),(187,'登录日志',1,'2017-07-23 22:39:59','成功',NULL,'127.0.0.1'),(188,'登录日志',1,'2017-07-25 19:59:34','成功',NULL,'127.0.0.1'),(189,'登录日志',1,'2017-07-25 20:24:13','成功',NULL,'127.0.0.1'),(190,'退出日志',1,'2017-07-25 20:35:11','成功',NULL,'127.0.0.1'),(191,'登录日志',1,'2017-07-25 20:35:26','成功',NULL,'127.0.0.1'),(192,'登录日志',1,'2017-07-25 22:54:26','成功',NULL,'127.0.0.1'),(193,'登录日志',1,'2017-07-26 19:57:02','成功',NULL,'127.0.0.1'),(194,'退出日志',1,'2017-07-26 23:15:03','成功',NULL,'127.0.0.1'),(195,'登录日志',1,'2017-07-26 23:15:11','成功',NULL,'127.0.0.1'),(196,'退出日志',1,'2017-07-26 23:55:42','成功',NULL,'127.0.0.1'),(197,'登录日志',1,'2017-07-26 23:55:49','成功',NULL,'127.0.0.1'),(198,'登录日志',1,'2017-07-27 20:17:25','成功',NULL,'127.0.0.1'),(199,'退出日志',1,'2017-07-27 20:20:15','成功',NULL,'127.0.0.1'),(200,'登录日志',1,'2017-07-27 20:20:24','成功',NULL,'127.0.0.1'),(201,'退出日志',1,'2017-07-27 21:11:31','成功',NULL,'127.0.0.1'),(202,'登录日志',1,'2017-07-27 21:11:37','成功',NULL,'127.0.0.1'),(203,'退出日志',1,'2017-07-27 22:44:31','成功',NULL,'127.0.0.1'),(204,'登录日志',1,'2017-07-27 22:44:38','成功',NULL,'127.0.0.1'),(205,'退出日志',1,'2017-07-27 22:55:46','成功',NULL,'127.0.0.1'),(206,'登录日志',1,'2017-07-27 22:55:54','成功',NULL,'127.0.0.1'),(207,'登录日志',1,'2017-07-28 18:14:01','成功',NULL,'127.0.0.1'),(208,'登录日志',1,'2017-07-29 11:03:34','成功',NULL,'127.0.0.1'),(209,'登录日志',1,'2017-07-29 20:33:24','成功',NULL,'127.0.0.1'),(210,'退出日志',1,'2017-07-29 21:03:59','成功',NULL,'127.0.0.1'),(211,'登录日志',305,'2017-07-29 21:04:08','成功',NULL,'127.0.0.1'),(212,'退出日志',305,'2017-07-29 21:04:14','成功',NULL,'127.0.0.1'),(213,'登录日志',1,'2017-07-29 21:04:23','成功',NULL,'127.0.0.1'),(214,'登录日志',1,'2017-07-29 22:08:50','成功',NULL,'127.0.0.1'),(215,'登录日志',1,'2017-07-29 22:23:34','成功',NULL,'127.0.0.1'),(216,'登录日志',1,'2017-07-30 08:49:00','成功',NULL,'127.0.0.1'),(217,'登录日志',1,'2017-07-30 12:36:38','成功',NULL,'127.0.0.1'),(218,'登录日志',1,'2017-07-30 14:10:31','成功',NULL,'127.0.0.1'),(219,'登录日志',1,'2017-08-03 09:14:09','成功',NULL,'127.0.0.1'),(220,'登录日志',44,'2017-08-03 09:31:30','成功',NULL,'127.0.0.1'),(221,'登录日志',44,'2017-08-03 10:09:40','成功',NULL,'127.0.0.1'),(222,'退出日志',44,'2017-08-03 10:11:01','成功',NULL,'127.0.0.1'),(223,'登录日志',44,'2017-08-03 10:11:03','成功',NULL,'127.0.0.1'),(224,'登录日志',1,'2017-08-03 10:11:31','成功',NULL,'127.0.0.1'),(225,'登录日志',1,'2017-08-03 10:15:41','成功',NULL,'127.0.0.1'),(226,'登录日志',44,'2017-08-03 18:32:55','成功',NULL,'127.0.0.1'),(227,'退出日志',44,'2017-08-03 18:33:56','成功',NULL,'127.0.0.1'),(228,'登录日志',44,'2017-08-03 18:34:02','成功',NULL,'127.0.0.1'),(229,'登录日志',44,'2017-08-03 18:43:13','成功',NULL,'127.0.0.1'),(230,'登录日志',44,'2017-08-05 10:07:47','成功',NULL,'127.0.0.1'),(231,'退出日志',44,'2017-08-05 10:10:55','成功',NULL,'127.0.0.1'),(232,'登录日志',44,'2017-08-05 10:10:57','成功',NULL,'127.0.0.1'),(233,'退出日志',44,'2017-08-05 10:23:09','成功',NULL,'127.0.0.1'),(234,'登录日志',44,'2017-08-05 10:23:10','成功',NULL,'127.0.0.1'),(235,'登录日志',44,'2017-08-05 10:34:00','成功',NULL,'127.0.0.1'),(236,'登录日志',44,'2017-08-05 10:35:59','成功',NULL,'127.0.0.1'),(237,'登录日志',44,'2017-08-05 10:59:37','成功',NULL,'127.0.0.1'),(238,'登录日志',44,'2017-08-05 11:03:14','成功',NULL,'127.0.0.1'),(239,'登录日志',44,'2017-08-05 11:03:43','成功',NULL,'127.0.0.1'),(240,'登录日志',44,'2017-08-05 11:04:01','成功',NULL,'127.0.0.1'),(241,'登录日志',44,'2017-08-05 11:04:14','成功',NULL,'127.0.0.1'),(242,'登录日志',44,'2017-08-05 11:05:43','成功',NULL,'127.0.0.1'),(243,'登录日志',44,'2017-08-05 11:06:07','成功',NULL,'127.0.0.1'),(244,'登录日志',44,'2017-08-05 11:06:24','成功',NULL,'127.0.0.1'),(245,'登录日志',44,'2017-08-05 11:06:33','成功',NULL,'127.0.0.1'),(246,'登录日志',44,'2017-08-05 11:08:07','成功',NULL,'127.0.0.1'),(247,'登录日志',44,'2017-08-05 11:08:24','成功',NULL,'127.0.0.1'),(248,'登录日志',44,'2017-08-05 11:08:33','成功',NULL,'127.0.0.1'),(249,'登录日志',44,'2017-08-05 12:25:34','成功',NULL,'127.0.0.1'),(250,'登录日志',44,'2017-08-05 12:27:33','成功',NULL,'127.0.0.1'),(251,'登录日志',44,'2017-08-05 12:47:26','成功',NULL,'127.0.0.1'),(252,'退出日志',44,'2017-08-05 12:50:57','成功',NULL,'127.0.0.1'),(253,'登录日志',44,'2017-08-05 12:58:26','成功',NULL,'127.0.0.1'),(254,'登录日志',44,'2017-08-05 12:59:29','成功',NULL,'127.0.0.1'),(255,'登录日志',44,'2017-08-05 12:59:30','成功',NULL,'127.0.0.1'),(256,'登录日志',44,'2017-08-05 13:04:30','成功',NULL,'127.0.0.1'),(257,'退出日志',44,'2017-08-05 13:05:54','成功',NULL,'127.0.0.1'),(258,'登录日志',44,'2017-08-05 13:05:57','成功',NULL,'127.0.0.1'),(259,'退出日志',44,'2017-08-05 13:06:10','成功',NULL,'127.0.0.1'),(260,'登录日志',44,'2017-08-05 13:06:12','成功',NULL,'127.0.0.1'),(261,'登录日志',44,'2017-08-05 13:12:22','成功',NULL,'127.0.0.1'),(262,'退出日志',44,'2017-08-05 13:47:47','成功',NULL,'127.0.0.1'),(263,'登录日志',44,'2017-08-05 13:47:49','成功',NULL,'127.0.0.1'),(264,'登录日志',44,'2017-08-05 13:50:51','成功',NULL,'127.0.0.1'),(265,'退出日志',44,'2017-08-05 14:01:34','成功',NULL,'127.0.0.1'),(266,'登录日志',44,'2017-08-05 14:01:35','成功',NULL,'127.0.0.1'),(267,'退出日志',44,'2017-08-05 14:06:44','成功',NULL,'127.0.0.1'),(268,'登录日志',44,'2017-08-05 14:06:45','成功',NULL,'127.0.0.1'),(269,'登录日志',44,'2017-08-05 17:04:33','成功',NULL,'127.0.0.1'),(270,'退出日志',44,'2017-08-05 17:08:09','成功',NULL,'127.0.0.1'),(271,'登录日志',1,'2017-08-05 19:01:15','成功',NULL,'127.0.0.1'),(272,'退出日志',1,'2017-08-05 19:08:08','成功',NULL,'127.0.0.1'),(273,'登录日志',44,'2017-08-05 19:15:08','成功',NULL,'127.0.0.1'),(274,'登录日志',44,'2017-08-05 19:37:06','成功',NULL,'127.0.0.1'),(275,'登录日志',44,'2017-08-05 19:51:44','成功',NULL,'127.0.0.1'),(276,'退出日志',44,'2017-08-05 19:52:24','成功',NULL,'127.0.0.1'),(277,'登录日志',44,'2017-08-05 19:55:29','成功',NULL,'127.0.0.1'),(278,'退出日志',44,'2017-08-05 19:59:30','成功',NULL,'127.0.0.1'),(279,'登录日志',44,'2017-08-05 19:59:31','成功',NULL,'127.0.0.1'),(280,'ログアウト',44,'2017-08-05 22:27:59','成功',NULL,'127.0.0.1'),(281,'ログイン成功',44,'2017-08-05 22:28:01','成功',NULL,'127.0.0.1');
/*!40000 ALTER TABLE `login_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` int(65) NOT NULL AUTO_INCREMENT COMMENT 'キーid',
  `code` varchar(255) DEFAULT NULL COMMENT 'メニー番号',
  `pcode` varchar(255) DEFAULT NULL COMMENT 'メニー親番号',
  `pcodes` varchar(255) DEFAULT NULL COMMENT '親メニー番号',
  `name` varchar(255) DEFAULT NULL COMMENT 'メニー名称',
  `icon` varchar(255) DEFAULT NULL COMMENT 'メニーアイコン',
  `url` varchar(255) DEFAULT NULL COMMENT 'urlアドレス',
  `num` int(65) DEFAULT NULL COMMENT 'メニー順番号',
  `levels` int(65) DEFAULT NULL COMMENT 'メニー等級',
  `ismenu` int(11) DEFAULT NULL COMMENT 'メニーそうですか（1：はい  0：いいえ）',
  `tips` varchar(255) DEFAULT NULL COMMENT '備考',
  `status` int(65) DEFAULT NULL COMMENT 'メニー状態 :  1:はい   0:いいえ',
  `isopen` int(11) DEFAULT NULL COMMENT '開けてない:    1:はい   0:いいえ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8 COMMENT='メニー表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (105,'system','0','[0],','システム管理','fa-user','',3,1,1,NULL,1,1),(106,'mgr','system','[0],[system],','ユーザー管理','','/mgr',1,2,1,NULL,1,0),(107,'mgr_add','mgr','[0],[system],[mgr],','新規ユーザー',NULL,'/mgr/add',1,3,0,NULL,1,0),(108,'mgr_edit','mgr','[0],[system],[mgr],','修正ユーザー',NULL,'/mgr/edit',2,3,0,NULL,1,0),(109,'mgr_delete','mgr','[0],[system],[mgr],','削除ユーザー',NULL,'/mgr/delete',3,3,0,NULL,1,0),(110,'mgr_reset','mgr','[0],[system],[mgr],','リセット密码',NULL,'/mgr/reset',4,3,0,NULL,1,0),(111,'mgr_freeze','mgr','[0],[system],[mgr],','凍結ユーザー',NULL,'/mgr/freeze',5,3,0,NULL,1,0),(112,'mgr_unfreeze','mgr','[0],[system],[mgr],','解凍ユーザー',NULL,'/mgr/unfreeze',6,3,0,NULL,1,0),(113,'mgr_setRole','mgr','[0],[system],[mgr],','分配ロール',NULL,'/mgr/setRole',7,3,0,NULL,1,0),(114,'role','system','[0],[system],','ロール管理',NULL,'/role',2,2,1,NULL,1,0),(115,'role_add','role','[0],[system],[role],','新規ロール',NULL,'/role/add',1,3,0,NULL,1,0),(116,'role_edit','role','[0],[system],[role],','修正ロール',NULL,'/role/edit',2,3,0,NULL,1,0),(117,'role_remove','role','[0],[system],[role],','削除ロール',NULL,'/role/remove',3,3,0,NULL,1,0),(118,'role_setAuthority','role','[0],[system],[role],','配置権限',NULL,'/role/setAuthority',4,3,0,NULL,1,0),(119,'menu','system','[0],[system],','メニー管理',NULL,'/menu',4,2,1,NULL,1,0),(120,'menu_add','menu','[0],[system],[menu],','新規メニー',NULL,'/menu/add',1,3,0,NULL,1,0),(121,'menu_edit','menu','[0],[system],[menu],','修正メニー',NULL,'/menu/edit',2,3,0,NULL,1,0),(122,'menu_remove','menu','[0],[system],[menu],','削除メニー',NULL,'/menu/remove',3,3,0,NULL,1,0),(128,'log','system','[0],[system],','業務ログ',NULL,'/log',6,2,1,NULL,1,0),(130,'druid','system','[0],[system],','監視管理',NULL,'/druid',7,2,1,NULL,1,NULL),(131,'dept','system','[0],[system],','部門管理',NULL,'/dept',3,2,1,NULL,1,NULL),(132,'dict','system','[0],[system],','辞書管理',NULL,'/dict',4,2,1,NULL,1,NULL),(133,'loginLog','system','[0],[system],','登録ログ',NULL,'/loginLog',6,2,1,NULL,1,NULL),(134,'log_clean','log','[0],[system],[log],','クリアログ',NULL,'/log/delLog',3,3,0,NULL,1,NULL),(135,'dept_add','dept','[0],[system],[dept],','新規部門',NULL,'/dept/add',1,3,0,NULL,1,NULL),(136,'dept_update','dept','[0],[system],[dept],','修正部門',NULL,'/dept/update',1,3,0,NULL,1,NULL),(137,'dept_delete','dept','[0],[system],[dept],','削除部門',NULL,'/dept/delete',1,3,0,NULL,1,NULL),(138,'dict_add','dict','[0],[system],[dict],','新規辞書',NULL,'/dict/add',1,3,0,NULL,1,NULL),(139,'dict_update','dict','[0],[system],[dict],','修正辞書',NULL,'/dict/update',1,3,0,NULL,1,NULL),(140,'dict_delete','dict','[0],[system],[dict],','削除辞書',NULL,'/dict/delete',1,3,0,NULL,1,NULL),(141,'notice','system','[0],[system],','お知らせ',NULL,'/notice',9,2,1,NULL,1,NULL),(142,'notice_add','notice','[0],[system],[notice],','新規お知らせ',NULL,'/notice/add',1,3,0,NULL,1,NULL),(143,'notice_update','notice','[0],[system],[notice],','修正お知らせ',NULL,'/notice/update',2,3,0,NULL,1,NULL),(144,'notice_delete','notice','[0],[system],[notice],','削除お知らせ',NULL,'/notice/delete',3,3,0,NULL,1,NULL),(145,'hello','0','[0],','お知らせ','fa-rocket','/notice/hello',1,1,1,NULL,1,NULL),(148,'code','system','[0],[system],','ソース作成','fa-user','/code',10,2,1,NULL,1,NULL),(149,'api_mgr','0','[0],','インタフェース','fa-leaf','/swagger-ui.html',2,1,1,NULL,1,NULL),(150,'to_menu_edit','menu','[0],[system],[menu],','メニー編集遷移','','/menu/menu_edit',4,3,0,NULL,1,NULL),(151,'menu_list','menu','[0],[system],[menu],','メニーリスト','','/menu/list',5,3,0,NULL,1,NULL),(152,'to_dept_update','dept','[0],[system],[dept],','修正部門遷移','','/dept/dept_update',4,3,0,NULL,1,NULL),(153,'dept_list','dept','[0],[system],[dept],','部門リスト','','/dept/list',5,3,0,NULL,1,NULL),(154,'dept_detail','dept','[0],[system],[dept],','部門詳細','','/dept/detail',6,3,0,NULL,1,NULL),(155,'to_dict_edit','dict','[0],[system],[dict],','修正メニー遷移','','/dict/dict_edit',4,3,0,NULL,1,NULL),(156,'dict_list','dict','[0],[system],[dict],','辞書リスト','','/dict/list',5,3,0,NULL,1,NULL),(157,'dict_detail','dict','[0],[system],[dict],','辞書詳細','','/dict/detail',6,3,0,NULL,1,NULL),(158,'log_list','log','[0],[system],[log],','ログリスト','','/log/list',2,3,0,NULL,1,NULL),(159,'log_detail','log','[0],[system],[log],','ログ詳細','','/log/detail',3,3,0,NULL,1,NULL),(160,'del_login_log','loginLog','[0],[system],[loginLog],','クリア登録ログ','','/loginLog/delLoginLog',1,3,0,NULL,1,NULL),(161,'login_log_list','loginLog','[0],[system],[loginLog],','登録ログリスト','','/loginLog/list',2,3,0,NULL,1,NULL),(162,'to_role_edit','role','[0],[system],[role],','修正ロール遷移','','/role/role_edit',5,3,0,NULL,1,NULL),(163,'to_role_assign','role','[0],[system],[role],','ロール分配遷移','','/role/role_assign',6,3,0,NULL,1,NULL),(164,'role_list','role','[0],[system],[role],','ロールリスト','','/role/list',7,3,0,NULL,1,NULL),(165,'to_assign_role','mgr','[0],[system],[mgr],','分配ロール遷移','','/mgr/role_assign',8,3,0,NULL,1,NULL),(166,'to_user_edit','mgr','[0],[system],[mgr],','編集ユーザー遷移','','/mgr/user_edit',9,3,0,NULL,1,NULL),(167,'mgr_list','mgr','[0],[system],[mgr],','ユーザーリスト','','/mgr/list',10,3,0,NULL,1,NULL);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menusubmenu`
--

DROP TABLE IF EXISTS `menusubmenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menusubmenu` (
  `menu_cd` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'メニューCD',
  `sub_menu_cd` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '子メニューCD',
  `display_order` int(11) NOT NULL COMMENT '表示順',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`menu_cd`,`sub_menu_cd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='メニュー・サブメニュー対照表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menusubmenu`
--

LOCK TABLES `menusubmenu` WRITE;
/*!40000 ALTER TABLE `menusubmenu` DISABLE KEYS */;
/*!40000 ALTER TABLE `menusubmenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moneyrev`
--

DROP TABLE IF EXISTS `moneyrev`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moneyrev` (
  `money_rec_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '入金ID',
  `req_dt` date NOT NULL COMMENT '入金日',
  `money_rec_amt` decimal(10,1) NOT NULL COMMENT '入金金額',
  `money_rec_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '入金備考',
  `req_id` int(11) NOT NULL COMMENT '請求ID',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`money_rec_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='入金';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moneyrev`
--

LOCK TABLES `moneyrev` WRITE;
/*!40000 ALTER TABLE `moneyrev` DISABLE KEYS */;
/*!40000 ALTER TABLE `moneyrev` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `noseqmgr`
--

DROP TABLE IF EXISTS `noseqmgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `noseqmgr` (
  `sys_cd` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'システムC',
  `sys_tbl_id` varchar(255) COLLATE utf8_bin NOT NULL COMMENT 'テーブルID',
  `sys_field` varchar(255) COLLATE utf8_bin NOT NULL COMMENT 'フィールドID',
  `sys_prefix` varchar(2) COLLATE utf8_bin NOT NULL COMMENT '接頭辞',
  `sys_ym` varchar(4) COLLATE utf8_bin NOT NULL COMMENT '年月',
  `sys_seq_start_no` int(11) NOT NULL COMMENT '開始NO',
  `sys_seq_end_no` int(11) NOT NULL COMMENT '終了NO',
  `sys_current_no` int(11) NOT NULL COMMENT 'カレントNO',
  `sys_field_remark` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '備考',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`sys_cd`,`sys_tbl_id`,`sys_field`),
  UNIQUE KEY `sysSetting_u1` (`sys_field`,`sys_ym`,`sys_seq_start_no`,`sys_seq_end_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='採番管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `noseqmgr`
--

LOCK TABLES `noseqmgr` WRITE;
/*!40000 ALTER TABLE `noseqmgr` DISABLE KEYS */;
/*!40000 ALTER TABLE `noseqmgr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'キー',
  `title` varchar(255) DEFAULT NULL COMMENT 'タイトル',
  `type` int(11) DEFAULT NULL COMMENT 'タイプ',
  `content` text COMMENT '内容',
  `createtime` datetime DEFAULT NULL COMMENT '作成時間',
  `creater` int(11) DEFAULT NULL COMMENT '作成者',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='お知らせ表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (6,'世界',10,'ようこそうWeb EDI 管理システム','2017-01-11 08:53:20',1),(8,'ようこそう',NULL,'ようこそうvv','2017-05-10 19:28:57',1);
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_log`
--

DROP TABLE IF EXISTS `operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operation_log` (
  `id` int(65) NOT NULL AUTO_INCREMENT COMMENT 'キー',
  `logtype` varchar(255) DEFAULT NULL COMMENT 'ログタイプ',
  `logname` varchar(255) DEFAULT NULL COMMENT 'ログ名称',
  `userid` int(65) DEFAULT NULL COMMENT 'ユーザーid',
  `classname` varchar(255) DEFAULT NULL COMMENT 'クラス名称',
  `method` text COMMENT 'メソッド名称',
  `createtime` datetime DEFAULT NULL COMMENT '作成時間',
  `succeed` varchar(255) DEFAULT NULL COMMENT '成功',
  `message` text COMMENT '備考',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=495 DEFAULT CHARSET=utf8 COMMENT='おべログ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_log`
--

LOCK TABLES `operation_log` WRITE;
/*!40000 ALTER TABLE `operation_log` DISABLE KEYS */;
INSERT INTO `operation_log` VALUES (480,'業務ログ','クリア業務ログ',1,'com.stylefeng.guns.modular.system.controller.LogController','delLog','2017-06-03 23:04:22','成功','キーid=null'),(481,'業務ログ','クリア登録ログ',1,'com.stylefeng.guns.modular.system.controller.LoginLogController','delLog','2017-06-03 23:04:25','成功','キーid=null'),(482,'業務ログ','修正メニー',1,'com.stylefeng.guns.modular.system.controller.MenuController','edit','2017-06-04 10:22:58','成功','メニー名称=分配ロール遷移;;;字段名称:urlアドレス,旧值:/role/role_assign,新值:/mgr/role_assign'),(483,'业务日志','修正通知',1,'com.stylefeng.guns.modular.system.controller.NoticeController','update','2017-07-04 19:55:51','成功','标题=ようこそう;;;字段名称:内容,旧值:ようこそう,新值:ようこそうvv'),(484,'异常日志','',1,NULL,NULL,'2017-07-04 20:00:23','失败','com.stylefeng.guns.common.exception.BussinessException: 原パスワード不正确\r\n	at com.stylefeng.guns.modular.system.controller.UserMgrController.changePwd(UserMgrController.java:152)\r\n	at com.stylefeng.guns.modular.system.controller.UserMgrControllerTTFastClassBySpringCGLIBTT87f11409.invoke(<generated>)\r\n	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:204)\r\n	at org.springframework.aop.framework.CglibAopProxyTCglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:738)\r\n	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:157)\r\n	at org.springframework.aop.aspectj.MethodInvocationProceedingJoinPoint.proceed(MethodInvocationProceedingJoinPoint.java:85)\r\n	at com.stylefeng.guns.core.intercept.SessionInterceptor.sessionKit(SessionInterceptor.java:31)\r\n	at sun.reflect.GeneratedMethodAccessor77.invoke(Unknown Source)\r\n	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n	at java.lang.reflect.Method.invoke(Method.java:498)\r\n	at org.springframework.aop.aspectj.AbstractAspectJAdvice.invokeAdviceMethodWithGivenArgs(AbstractAspectJAdvice.java:629)\r\n	at org.springframework.aop.aspectj.AbstractAspectJAdvice.invokeAdviceMethod(AbstractAspectJAdvice.java:618)\r\n	at org.springframework.aop.aspectj.AspectJAroundAdvice.invoke(AspectJAroundAdvice.java:70)\r\n	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:179)\r\n	at org.springframework.aop.interceptor.ExposeInvocationInterceptor.invoke(ExposeInvocationInterceptor.java:92)\r\n	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:179)\r\n	at org.springframework.aop.framework.CglibAopProxyTDynamicAdvisedInterceptor.intercept(CglibAopProxy.java:673)\r\n	at com.stylefeng.guns.modular.system.controller.UserMgrControllerTTEnhancerBySpringCGLIBTTb7997a3e.changePwd(<generated>)\r\n	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\r\n	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n	at java.lang.reflect.Method.invoke(Method.java:498)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.doInvoke(InvocableHandlerMethod.java:205)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.invokeForRequest(InvocableHandlerMethod.java:133)\r\n	at org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod.invokeAndHandle(ServletInvocableHandlerMethod.java:97)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.invokeHandlerMethod(RequestMappingHandlerAdapter.java:827)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.handleInternal(RequestMappingHandlerAdapter.java:738)\r\n	at org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter.handle(AbstractHandlerMethodAdapter.java:85)\r\n	at org.springframework.web.servlet.DispatcherServlet.doDispatch(DispatcherServlet.java:963)\r\n	at org.springframework.web.servlet.DispatcherServlet.doService(DispatcherServlet.java:897)\r\n	at org.springframework.web.servlet.FrameworkServlet.processRequest(FrameworkServlet.java:970)\r\n	at org.springframework.web.servlet.FrameworkServlet.doPost(FrameworkServlet.java:872)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:661)\r\n	at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:846)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:742)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:231)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.tomcat.websocket.server.WsFilter.doFilter(WsFilter.java:52)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:61)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.executeChain(AdviceFilter.java:108)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.doFilterInternal(AdviceFilter.java:137)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:66)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.executeChain(AbstractShiroFilter.java:449)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilterT1.call(AbstractShiroFilter.java:365)\r\n	at org.apache.shiro.subject.support.SubjectCallable.doCall(SubjectCallable.java:90)\r\n	at org.apache.shiro.subject.support.SubjectCallable.call(SubjectCallable.java:83)\r\n	at org.apache.shiro.subject.support.DelegatingSubject.execute(DelegatingSubject.java:387)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.doFilterInternal(AbstractShiroFilter.java:362)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.stylefeng.guns.core.util.xss.XssFilter.doFilter(XssFilter.java:22)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.alibaba.druid.support.http.WebStatFilter.doFilter(WebStatFilter.java:123)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.RequestContextFilter.doFilterInternal(RequestContextFilter.java:99)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HttpPutFormContentFilter.doFilterInternal(HttpPutFormContentFilter.java:105)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HiddenHttpMethodFilter.doFilterInternal(HiddenHttpMethodFilter.java:81)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.CharacterEncodingFilter.doFilterInternal(CharacterEncodingFilter.java:197)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:198)\r\n	at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:96)\r\n	at org.apache.catalina.authenticator.AuthenticatorBase.invoke(AuthenticatorBase.java:478)\r\n	at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:140)\r\n	at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:80)\r\n	at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:87)\r\n	at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:342)\r\n	at org.apache.coyote.http11.Http11Processor.service(Http11Processor.java:799)\r\n	at org.apache.coyote.AbstractProcessorLight.process(AbstractProcessorLight.java:66)\r\n	at org.apache.coyote.AbstractProtocolTConnectionHandler.process(AbstractProtocol.java:861)\r\n	at org.apache.tomcat.util.net.NioEndpointTSocketProcessor.doRun(NioEndpoint.java:1455)\r\n	at org.apache.tomcat.util.net.SocketProcessorBase.run(SocketProcessorBase.java:49)\r\n	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)\r\n	at java.util.concurrent.ThreadPoolExecutorTWorker.run(ThreadPoolExecutor.java:617)\r\n	at org.apache.tomcat.util.threads.TaskThreadTWrappingRunnable.run(TaskThread.java:61)\r\n	at java.lang.Thread.run(Thread.java:745)\r\n'),(485,'异常日志','',1,NULL,NULL,'2017-07-04 20:00:28','失败','com.stylefeng.guns.common.exception.BussinessException: 原パスワード不正确\r\n	at com.stylefeng.guns.modular.system.controller.UserMgrController.changePwd(UserMgrController.java:152)\r\n	at com.stylefeng.guns.modular.system.controller.UserMgrControllerTTFastClassBySpringCGLIBTT87f11409.invoke(<generated>)\r\n	at org.springframework.cglib.proxy.MethodProxy.invoke(MethodProxy.java:204)\r\n	at org.springframework.aop.framework.CglibAopProxyTCglibMethodInvocation.invokeJoinpoint(CglibAopProxy.java:738)\r\n	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:157)\r\n	at org.springframework.aop.aspectj.MethodInvocationProceedingJoinPoint.proceed(MethodInvocationProceedingJoinPoint.java:85)\r\n	at com.stylefeng.guns.core.intercept.SessionInterceptor.sessionKit(SessionInterceptor.java:31)\r\n	at sun.reflect.GeneratedMethodAccessor77.invoke(Unknown Source)\r\n	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n	at java.lang.reflect.Method.invoke(Method.java:498)\r\n	at org.springframework.aop.aspectj.AbstractAspectJAdvice.invokeAdviceMethodWithGivenArgs(AbstractAspectJAdvice.java:629)\r\n	at org.springframework.aop.aspectj.AbstractAspectJAdvice.invokeAdviceMethod(AbstractAspectJAdvice.java:618)\r\n	at org.springframework.aop.aspectj.AspectJAroundAdvice.invoke(AspectJAroundAdvice.java:70)\r\n	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:179)\r\n	at org.springframework.aop.interceptor.ExposeInvocationInterceptor.invoke(ExposeInvocationInterceptor.java:92)\r\n	at org.springframework.aop.framework.ReflectiveMethodInvocation.proceed(ReflectiveMethodInvocation.java:179)\r\n	at org.springframework.aop.framework.CglibAopProxyTDynamicAdvisedInterceptor.intercept(CglibAopProxy.java:673)\r\n	at com.stylefeng.guns.modular.system.controller.UserMgrControllerTTEnhancerBySpringCGLIBTTb7997a3e.changePwd(<generated>)\r\n	at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)\r\n	at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)\r\n	at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)\r\n	at java.lang.reflect.Method.invoke(Method.java:498)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.doInvoke(InvocableHandlerMethod.java:205)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.invokeForRequest(InvocableHandlerMethod.java:133)\r\n	at org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod.invokeAndHandle(ServletInvocableHandlerMethod.java:97)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.invokeHandlerMethod(RequestMappingHandlerAdapter.java:827)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.handleInternal(RequestMappingHandlerAdapter.java:738)\r\n	at org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter.handle(AbstractHandlerMethodAdapter.java:85)\r\n	at org.springframework.web.servlet.DispatcherServlet.doDispatch(DispatcherServlet.java:963)\r\n	at org.springframework.web.servlet.DispatcherServlet.doService(DispatcherServlet.java:897)\r\n	at org.springframework.web.servlet.FrameworkServlet.processRequest(FrameworkServlet.java:970)\r\n	at org.springframework.web.servlet.FrameworkServlet.doPost(FrameworkServlet.java:872)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:661)\r\n	at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:846)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:742)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:231)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.tomcat.websocket.server.WsFilter.doFilter(WsFilter.java:52)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:61)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.executeChain(AdviceFilter.java:108)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.doFilterInternal(AdviceFilter.java:137)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:66)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.executeChain(AbstractShiroFilter.java:449)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilterT1.call(AbstractShiroFilter.java:365)\r\n	at org.apache.shiro.subject.support.SubjectCallable.doCall(SubjectCallable.java:90)\r\n	at org.apache.shiro.subject.support.SubjectCallable.call(SubjectCallable.java:83)\r\n	at org.apache.shiro.subject.support.DelegatingSubject.execute(DelegatingSubject.java:387)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.doFilterInternal(AbstractShiroFilter.java:362)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.stylefeng.guns.core.util.xss.XssFilter.doFilter(XssFilter.java:22)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.alibaba.druid.support.http.WebStatFilter.doFilter(WebStatFilter.java:123)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.RequestContextFilter.doFilterInternal(RequestContextFilter.java:99)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HttpPutFormContentFilter.doFilterInternal(HttpPutFormContentFilter.java:105)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HiddenHttpMethodFilter.doFilterInternal(HiddenHttpMethodFilter.java:81)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.CharacterEncodingFilter.doFilterInternal(CharacterEncodingFilter.java:197)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:198)\r\n	at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:96)\r\n	at org.apache.catalina.authenticator.AuthenticatorBase.invoke(AuthenticatorBase.java:478)\r\n	at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:140)\r\n	at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:80)\r\n	at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:87)\r\n	at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:342)\r\n	at org.apache.coyote.http11.Http11Processor.service(Http11Processor.java:799)\r\n	at org.apache.coyote.AbstractProcessorLight.process(AbstractProcessorLight.java:66)\r\n	at org.apache.coyote.AbstractProtocolTConnectionHandler.process(AbstractProtocol.java:861)\r\n	at org.apache.tomcat.util.net.NioEndpointTSocketProcessor.doRun(NioEndpoint.java:1455)\r\n	at org.apache.tomcat.util.net.SocketProcessorBase.run(SocketProcessorBase.java:49)\r\n	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)\r\n	at java.util.concurrent.ThreadPoolExecutorTWorker.run(ThreadPoolExecutor.java:617)\r\n	at org.apache.tomcat.util.threads.TaskThreadTWrappingRunnable.run(TaskThread.java:61)\r\n	at java.lang.Thread.run(Thread.java:745)\r\n'),(486,'异常日志','',1,NULL,NULL,'2017-07-23 20:20:43','失败','org.springframework.http.converter.HttpMessageNotReadableException: Required request body is missing: public com.tsrs.webedi.common.JsonResult com.tsrs.webedi.modular.system.controller.LoginController.login(com.tsrs.webedi.common.persistence.model.User)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.readWithMessageConverters(RequestResponseBodyMethodProcessor.java:154)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.resolveArgument(RequestResponseBodyMethodProcessor.java:128)\r\n	at org.springframework.web.method.support.HandlerMethodArgumentResolverComposite.resolveArgument(HandlerMethodArgumentResolverComposite.java:121)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.getMethodArgumentValues(InvocableHandlerMethod.java:158)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.invokeForRequest(InvocableHandlerMethod.java:128)\r\n	at org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod.invokeAndHandle(ServletInvocableHandlerMethod.java:97)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.invokeHandlerMethod(RequestMappingHandlerAdapter.java:827)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.handleInternal(RequestMappingHandlerAdapter.java:738)\r\n	at org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter.handle(AbstractHandlerMethodAdapter.java:85)\r\n	at org.springframework.web.servlet.DispatcherServlet.doDispatch(DispatcherServlet.java:963)\r\n	at org.springframework.web.servlet.DispatcherServlet.doService(DispatcherServlet.java:897)\r\n	at org.springframework.web.servlet.FrameworkServlet.processRequest(FrameworkServlet.java:970)\r\n	at org.springframework.web.servlet.FrameworkServlet.doGet(FrameworkServlet.java:861)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:635)\r\n	at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:846)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:742)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:231)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.tomcat.websocket.server.WsFilter.doFilter(WsFilter.java:52)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:61)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.executeChain(AdviceFilter.java:108)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.doFilterInternal(AdviceFilter.java:137)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:66)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.executeChain(AbstractShiroFilter.java:449)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilterT1.call(AbstractShiroFilter.java:365)\r\n	at org.apache.shiro.subject.support.SubjectCallable.doCall(SubjectCallable.java:90)\r\n	at org.apache.shiro.subject.support.SubjectCallable.call(SubjectCallable.java:83)\r\n	at org.apache.shiro.subject.support.DelegatingSubject.execute(DelegatingSubject.java:387)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.doFilterInternal(AbstractShiroFilter.java:362)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.tsrs.webedi.core.util.xss.XssFilter.doFilter(XssFilter.java:22)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.alibaba.druid.support.http.WebStatFilter.doFilter(WebStatFilter.java:123)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.RequestContextFilter.doFilterInternal(RequestContextFilter.java:99)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HttpPutFormContentFilter.doFilterInternal(HttpPutFormContentFilter.java:105)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HiddenHttpMethodFilter.doFilterInternal(HiddenHttpMethodFilter.java:81)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.CharacterEncodingFilter.doFilterInternal(CharacterEncodingFilter.java:197)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:198)\r\n	at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:96)\r\n	at org.apache.catalina.authenticator.AuthenticatorBase.invoke(AuthenticatorBase.java:478)\r\n	at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:140)\r\n	at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:80)\r\n	at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:87)\r\n	at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:342)\r\n	at org.apache.coyote.http11.Http11Processor.service(Http11Processor.java:799)\r\n	at org.apache.coyote.AbstractProcessorLight.process(AbstractProcessorLight.java:66)\r\n	at org.apache.coyote.AbstractProtocolTConnectionHandler.process(AbstractProtocol.java:861)\r\n	at org.apache.tomcat.util.net.NioEndpointTSocketProcessor.doRun(NioEndpoint.java:1455)\r\n	at org.apache.tomcat.util.net.SocketProcessorBase.run(SocketProcessorBase.java:49)\r\n	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)\r\n	at java.util.concurrent.ThreadPoolExecutorTWorker.run(ThreadPoolExecutor.java:617)\r\n	at org.apache.tomcat.util.threads.TaskThreadTWrappingRunnable.run(TaskThread.java:61)\r\n	at java.lang.Thread.run(Thread.java:745)\r\n'),(487,'异常日志','',1,NULL,NULL,'2017-07-23 20:20:46','失败','org.springframework.http.converter.HttpMessageNotReadableException: Required request body is missing: public com.tsrs.webedi.common.JsonResult com.tsrs.webedi.modular.system.controller.LoginController.login(com.tsrs.webedi.common.persistence.model.User)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.readWithMessageConverters(RequestResponseBodyMethodProcessor.java:154)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.resolveArgument(RequestResponseBodyMethodProcessor.java:128)\r\n	at org.springframework.web.method.support.HandlerMethodArgumentResolverComposite.resolveArgument(HandlerMethodArgumentResolverComposite.java:121)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.getMethodArgumentValues(InvocableHandlerMethod.java:158)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.invokeForRequest(InvocableHandlerMethod.java:128)\r\n	at org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod.invokeAndHandle(ServletInvocableHandlerMethod.java:97)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.invokeHandlerMethod(RequestMappingHandlerAdapter.java:827)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.handleInternal(RequestMappingHandlerAdapter.java:738)\r\n	at org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter.handle(AbstractHandlerMethodAdapter.java:85)\r\n	at org.springframework.web.servlet.DispatcherServlet.doDispatch(DispatcherServlet.java:963)\r\n	at org.springframework.web.servlet.DispatcherServlet.doService(DispatcherServlet.java:897)\r\n	at org.springframework.web.servlet.FrameworkServlet.processRequest(FrameworkServlet.java:970)\r\n	at org.springframework.web.servlet.FrameworkServlet.doGet(FrameworkServlet.java:861)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:635)\r\n	at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:846)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:742)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:231)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.tomcat.websocket.server.WsFilter.doFilter(WsFilter.java:52)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:61)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.executeChain(AdviceFilter.java:108)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.doFilterInternal(AdviceFilter.java:137)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:66)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.executeChain(AbstractShiroFilter.java:449)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilterT1.call(AbstractShiroFilter.java:365)\r\n	at org.apache.shiro.subject.support.SubjectCallable.doCall(SubjectCallable.java:90)\r\n	at org.apache.shiro.subject.support.SubjectCallable.call(SubjectCallable.java:83)\r\n	at org.apache.shiro.subject.support.DelegatingSubject.execute(DelegatingSubject.java:387)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.doFilterInternal(AbstractShiroFilter.java:362)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.tsrs.webedi.core.util.xss.XssFilter.doFilter(XssFilter.java:22)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.alibaba.druid.support.http.WebStatFilter.doFilter(WebStatFilter.java:123)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.RequestContextFilter.doFilterInternal(RequestContextFilter.java:99)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HttpPutFormContentFilter.doFilterInternal(HttpPutFormContentFilter.java:105)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HiddenHttpMethodFilter.doFilterInternal(HiddenHttpMethodFilter.java:81)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.CharacterEncodingFilter.doFilterInternal(CharacterEncodingFilter.java:197)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:198)\r\n	at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:96)\r\n	at org.apache.catalina.authenticator.AuthenticatorBase.invoke(AuthenticatorBase.java:478)\r\n	at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:140)\r\n	at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:80)\r\n	at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:87)\r\n	at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:342)\r\n	at org.apache.coyote.http11.Http11Processor.service(Http11Processor.java:799)\r\n	at org.apache.coyote.AbstractProcessorLight.process(AbstractProcessorLight.java:66)\r\n	at org.apache.coyote.AbstractProtocolTConnectionHandler.process(AbstractProtocol.java:861)\r\n	at org.apache.tomcat.util.net.NioEndpointTSocketProcessor.doRun(NioEndpoint.java:1455)\r\n	at org.apache.tomcat.util.net.SocketProcessorBase.run(SocketProcessorBase.java:49)\r\n	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)\r\n	at java.util.concurrent.ThreadPoolExecutorTWorker.run(ThreadPoolExecutor.java:617)\r\n	at org.apache.tomcat.util.threads.TaskThreadTWrappingRunnable.run(TaskThread.java:61)\r\n	at java.lang.Thread.run(Thread.java:745)\r\n'),(488,'异常日志','',1,NULL,NULL,'2017-07-23 20:20:46','失败','org.springframework.http.converter.HttpMessageNotReadableException: Required request body is missing: public com.tsrs.webedi.common.JsonResult com.tsrs.webedi.modular.system.controller.LoginController.login(com.tsrs.webedi.common.persistence.model.User)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.readWithMessageConverters(RequestResponseBodyMethodProcessor.java:154)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.resolveArgument(RequestResponseBodyMethodProcessor.java:128)\r\n	at org.springframework.web.method.support.HandlerMethodArgumentResolverComposite.resolveArgument(HandlerMethodArgumentResolverComposite.java:121)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.getMethodArgumentValues(InvocableHandlerMethod.java:158)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.invokeForRequest(InvocableHandlerMethod.java:128)\r\n	at org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod.invokeAndHandle(ServletInvocableHandlerMethod.java:97)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.invokeHandlerMethod(RequestMappingHandlerAdapter.java:827)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.handleInternal(RequestMappingHandlerAdapter.java:738)\r\n	at org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter.handle(AbstractHandlerMethodAdapter.java:85)\r\n	at org.springframework.web.servlet.DispatcherServlet.doDispatch(DispatcherServlet.java:963)\r\n	at org.springframework.web.servlet.DispatcherServlet.doService(DispatcherServlet.java:897)\r\n	at org.springframework.web.servlet.FrameworkServlet.processRequest(FrameworkServlet.java:970)\r\n	at org.springframework.web.servlet.FrameworkServlet.doGet(FrameworkServlet.java:861)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:635)\r\n	at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:846)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:742)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:231)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.tomcat.websocket.server.WsFilter.doFilter(WsFilter.java:52)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:61)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.executeChain(AdviceFilter.java:108)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.doFilterInternal(AdviceFilter.java:137)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:66)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.executeChain(AbstractShiroFilter.java:449)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilterT1.call(AbstractShiroFilter.java:365)\r\n	at org.apache.shiro.subject.support.SubjectCallable.doCall(SubjectCallable.java:90)\r\n	at org.apache.shiro.subject.support.SubjectCallable.call(SubjectCallable.java:83)\r\n	at org.apache.shiro.subject.support.DelegatingSubject.execute(DelegatingSubject.java:387)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.doFilterInternal(AbstractShiroFilter.java:362)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.tsrs.webedi.core.util.xss.XssFilter.doFilter(XssFilter.java:22)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.alibaba.druid.support.http.WebStatFilter.doFilter(WebStatFilter.java:123)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.RequestContextFilter.doFilterInternal(RequestContextFilter.java:99)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HttpPutFormContentFilter.doFilterInternal(HttpPutFormContentFilter.java:105)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HiddenHttpMethodFilter.doFilterInternal(HiddenHttpMethodFilter.java:81)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.CharacterEncodingFilter.doFilterInternal(CharacterEncodingFilter.java:197)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:198)\r\n	at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:96)\r\n	at org.apache.catalina.authenticator.AuthenticatorBase.invoke(AuthenticatorBase.java:478)\r\n	at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:140)\r\n	at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:80)\r\n	at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:87)\r\n	at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:342)\r\n	at org.apache.coyote.http11.Http11Processor.service(Http11Processor.java:799)\r\n	at org.apache.coyote.AbstractProcessorLight.process(AbstractProcessorLight.java:66)\r\n	at org.apache.coyote.AbstractProtocolTConnectionHandler.process(AbstractProtocol.java:861)\r\n	at org.apache.tomcat.util.net.NioEndpointTSocketProcessor.doRun(NioEndpoint.java:1455)\r\n	at org.apache.tomcat.util.net.SocketProcessorBase.run(SocketProcessorBase.java:49)\r\n	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)\r\n	at java.util.concurrent.ThreadPoolExecutorTWorker.run(ThreadPoolExecutor.java:617)\r\n	at org.apache.tomcat.util.threads.TaskThreadTWrappingRunnable.run(TaskThread.java:61)\r\n	at java.lang.Thread.run(Thread.java:745)\r\n'),(489,'业务日志','リセットパスワード',1,'com.tsrs.webedi.modular.system.controller.UserMgrController','resetPwd','2017-07-25 20:36:44','成功','アカウント=null'),(490,'异常日志','',1,NULL,NULL,'2017-07-30 12:53:53','失败','com.alibaba.fastjson.JSONException: For input string: \"a\"\r\n	at com.alibaba.fastjson.parser.DefaultJSONParser.parseObject(DefaultJSONParser.java:646)\r\n	at com.alibaba.fastjson.JSON.parseObject(JSON.java:350)\r\n	at com.alibaba.fastjson.JSON.parseObject(JSON.java:318)\r\n	at com.alibaba.fastjson.JSON.parseObject(JSON.java:281)\r\n	at com.alibaba.fastjson.JSON.parseObject(JSON.java:381)\r\n	at com.alibaba.fastjson.JSON.parseObject(JSON.java:463)\r\n	at com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter.read(FastJsonHttpMessageConverter.java:211)\r\n	at org.springframework.web.servlet.mvc.method.annotation.AbstractMessageConverterMethodArgumentResolver.readWithMessageConverters(AbstractMessageConverterMethodArgumentResolver.java:201)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.readWithMessageConverters(RequestResponseBodyMethodProcessor.java:150)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.resolveArgument(RequestResponseBodyMethodProcessor.java:128)\r\n	at org.springframework.web.method.support.HandlerMethodArgumentResolverComposite.resolveArgument(HandlerMethodArgumentResolverComposite.java:121)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.getMethodArgumentValues(InvocableHandlerMethod.java:158)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.invokeForRequest(InvocableHandlerMethod.java:128)\r\n	at org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod.invokeAndHandle(ServletInvocableHandlerMethod.java:97)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.invokeHandlerMethod(RequestMappingHandlerAdapter.java:827)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.handleInternal(RequestMappingHandlerAdapter.java:738)\r\n	at org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter.handle(AbstractHandlerMethodAdapter.java:85)\r\n	at org.springframework.web.servlet.DispatcherServlet.doDispatch(DispatcherServlet.java:963)\r\n	at org.springframework.web.servlet.DispatcherServlet.doService(DispatcherServlet.java:897)\r\n	at org.springframework.web.servlet.FrameworkServlet.processRequest(FrameworkServlet.java:970)\r\n	at org.springframework.web.servlet.FrameworkServlet.doPost(FrameworkServlet.java:872)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:661)\r\n	at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:846)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:742)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:231)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.tomcat.websocket.server.WsFilter.doFilter(WsFilter.java:52)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:61)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.executeChain(AdviceFilter.java:108)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.doFilterInternal(AdviceFilter.java:137)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:66)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.executeChain(AbstractShiroFilter.java:449)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilterT1.call(AbstractShiroFilter.java:365)\r\n	at org.apache.shiro.subject.support.SubjectCallable.doCall(SubjectCallable.java:90)\r\n	at org.apache.shiro.subject.support.SubjectCallable.call(SubjectCallable.java:83)\r\n	at org.apache.shiro.subject.support.DelegatingSubject.execute(DelegatingSubject.java:387)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.doFilterInternal(AbstractShiroFilter.java:362)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.tsrs.webedi.core.util.xss.XssFilter.doFilter(XssFilter.java:22)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.alibaba.druid.support.http.WebStatFilter.doFilter(WebStatFilter.java:123)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.RequestContextFilter.doFilterInternal(RequestContextFilter.java:99)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HttpPutFormContentFilter.doFilterInternal(HttpPutFormContentFilter.java:105)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HiddenHttpMethodFilter.doFilterInternal(HiddenHttpMethodFilter.java:81)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.CharacterEncodingFilter.doFilterInternal(CharacterEncodingFilter.java:197)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:198)\r\n	at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:96)\r\n	at org.apache.catalina.authenticator.AuthenticatorBase.invoke(AuthenticatorBase.java:478)\r\n	at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:140)\r\n	at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:80)\r\n	at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:87)\r\n	at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:342)\r\n	at org.apache.coyote.http11.Http11Processor.service(Http11Processor.java:799)\r\n	at org.apache.coyote.AbstractProcessorLight.process(AbstractProcessorLight.java:66)\r\n	at org.apache.coyote.AbstractProtocolTConnectionHandler.process(AbstractProtocol.java:861)\r\n	at org.apache.tomcat.util.net.NioEndpointTSocketProcessor.doRun(NioEndpoint.java:1455)\r\n	at org.apache.tomcat.util.net.SocketProcessorBase.run(SocketProcessorBase.java:49)\r\n	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)\r\n	at java.util.concurrent.ThreadPoolExecutorTWorker.run(ThreadPoolExecutor.java:617)\r\n	at org.apache.tomcat.util.threads.TaskThreadTWrappingRunnable.run(TaskThread.java:61)\r\n	at java.lang.Thread.run(Thread.java:745)\r\nCaused by: java.lang.NumberFormatException: For input string: \"a\"\r\n	at java.lang.NumberFormatException.forInputString(NumberFormatException.java:65)\r\n	at java.lang.Integer.parseInt(Integer.java:580)\r\n	at java.lang.Integer.parseInt(Integer.java:615)\r\n	at com.alibaba.fastjson.util.TypeUtils.castToInt(TypeUtils.java:578)\r\n	at com.alibaba.fastjson.serializer.IntegerCodec.deserialze(IntegerCodec.java:100)\r\n	at com.alibaba.fastjson.parser.deserializer.FastjsonASMDeserializer_2_UserWfConfirmRoute.deserialze(Unknown Source)\r\n	at com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.deserialze(JavaBeanDeserializer.java:208)\r\n	at com.alibaba.fastjson.parser.deserializer.ArrayListTypeFieldDeserializer.parseArray(ArrayListTypeFieldDeserializer.java:158)\r\n	at com.alibaba.fastjson.parser.deserializer.ArrayListTypeFieldDeserializer.parseField(ArrayListTypeFieldDeserializer.java:62)\r\n	at com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.parseField(JavaBeanDeserializer.java:828)\r\n	at com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.deserialze(JavaBeanDeserializer.java:630)\r\n	at com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.parseRest(JavaBeanDeserializer.java:1010)\r\n	at com.alibaba.fastjson.parser.deserializer.FastjsonASMDeserializer_1_UserExt.deserialze(Unknown Source)\r\n	at com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.deserialze(JavaBeanDeserializer.java:208)\r\n	at com.alibaba.fastjson.parser.DefaultJSONParser.parseObject(DefaultJSONParser.java:642)\r\n	... 80 more\r\n'),(491,'异常日志','',1,NULL,NULL,'2017-07-30 12:54:20','失败','com.alibaba.fastjson.JSONException: For input string: \"a\"\r\n	at com.alibaba.fastjson.parser.DefaultJSONParser.parseObject(DefaultJSONParser.java:646)\r\n	at com.alibaba.fastjson.JSON.parseObject(JSON.java:350)\r\n	at com.alibaba.fastjson.JSON.parseObject(JSON.java:318)\r\n	at com.alibaba.fastjson.JSON.parseObject(JSON.java:281)\r\n	at com.alibaba.fastjson.JSON.parseObject(JSON.java:381)\r\n	at com.alibaba.fastjson.JSON.parseObject(JSON.java:463)\r\n	at com.alibaba.fastjson.support.spring.FastJsonHttpMessageConverter.read(FastJsonHttpMessageConverter.java:211)\r\n	at org.springframework.web.servlet.mvc.method.annotation.AbstractMessageConverterMethodArgumentResolver.readWithMessageConverters(AbstractMessageConverterMethodArgumentResolver.java:201)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.readWithMessageConverters(RequestResponseBodyMethodProcessor.java:150)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor.resolveArgument(RequestResponseBodyMethodProcessor.java:128)\r\n	at org.springframework.web.method.support.HandlerMethodArgumentResolverComposite.resolveArgument(HandlerMethodArgumentResolverComposite.java:121)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.getMethodArgumentValues(InvocableHandlerMethod.java:158)\r\n	at org.springframework.web.method.support.InvocableHandlerMethod.invokeForRequest(InvocableHandlerMethod.java:128)\r\n	at org.springframework.web.servlet.mvc.method.annotation.ServletInvocableHandlerMethod.invokeAndHandle(ServletInvocableHandlerMethod.java:97)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.invokeHandlerMethod(RequestMappingHandlerAdapter.java:827)\r\n	at org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter.handleInternal(RequestMappingHandlerAdapter.java:738)\r\n	at org.springframework.web.servlet.mvc.method.AbstractHandlerMethodAdapter.handle(AbstractHandlerMethodAdapter.java:85)\r\n	at org.springframework.web.servlet.DispatcherServlet.doDispatch(DispatcherServlet.java:963)\r\n	at org.springframework.web.servlet.DispatcherServlet.doService(DispatcherServlet.java:897)\r\n	at org.springframework.web.servlet.FrameworkServlet.processRequest(FrameworkServlet.java:970)\r\n	at org.springframework.web.servlet.FrameworkServlet.doPost(FrameworkServlet.java:872)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:661)\r\n	at org.springframework.web.servlet.FrameworkServlet.service(FrameworkServlet.java:846)\r\n	at javax.servlet.http.HttpServlet.service(HttpServlet.java:742)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:231)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.tomcat.websocket.server.WsFilter.doFilter(WsFilter.java:52)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:61)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.executeChain(AdviceFilter.java:108)\r\n	at org.apache.shiro.web.servlet.AdviceFilter.doFilterInternal(AdviceFilter.java:137)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.shiro.web.servlet.ProxiedFilterChain.doFilter(ProxiedFilterChain.java:66)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.executeChain(AbstractShiroFilter.java:449)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilterT1.call(AbstractShiroFilter.java:365)\r\n	at org.apache.shiro.subject.support.SubjectCallable.doCall(SubjectCallable.java:90)\r\n	at org.apache.shiro.subject.support.SubjectCallable.call(SubjectCallable.java:83)\r\n	at org.apache.shiro.subject.support.DelegatingSubject.execute(DelegatingSubject.java:387)\r\n	at org.apache.shiro.web.servlet.AbstractShiroFilter.doFilterInternal(AbstractShiroFilter.java:362)\r\n	at org.apache.shiro.web.servlet.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:125)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.tsrs.webedi.core.util.xss.XssFilter.doFilter(XssFilter.java:22)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at com.alibaba.druid.support.http.WebStatFilter.doFilter(WebStatFilter.java:123)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.RequestContextFilter.doFilterInternal(RequestContextFilter.java:99)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HttpPutFormContentFilter.doFilterInternal(HttpPutFormContentFilter.java:105)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.HiddenHttpMethodFilter.doFilterInternal(HiddenHttpMethodFilter.java:81)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.springframework.web.filter.CharacterEncodingFilter.doFilterInternal(CharacterEncodingFilter.java:197)\r\n	at org.springframework.web.filter.OncePerRequestFilter.doFilter(OncePerRequestFilter.java:107)\r\n	at org.apache.catalina.core.ApplicationFilterChain.internalDoFilter(ApplicationFilterChain.java:193)\r\n	at org.apache.catalina.core.ApplicationFilterChain.doFilter(ApplicationFilterChain.java:166)\r\n	at org.apache.catalina.core.StandardWrapperValve.invoke(StandardWrapperValve.java:198)\r\n	at org.apache.catalina.core.StandardContextValve.invoke(StandardContextValve.java:96)\r\n	at org.apache.catalina.authenticator.AuthenticatorBase.invoke(AuthenticatorBase.java:478)\r\n	at org.apache.catalina.core.StandardHostValve.invoke(StandardHostValve.java:140)\r\n	at org.apache.catalina.valves.ErrorReportValve.invoke(ErrorReportValve.java:80)\r\n	at org.apache.catalina.core.StandardEngineValve.invoke(StandardEngineValve.java:87)\r\n	at org.apache.catalina.connector.CoyoteAdapter.service(CoyoteAdapter.java:342)\r\n	at org.apache.coyote.http11.Http11Processor.service(Http11Processor.java:799)\r\n	at org.apache.coyote.AbstractProcessorLight.process(AbstractProcessorLight.java:66)\r\n	at org.apache.coyote.AbstractProtocolTConnectionHandler.process(AbstractProtocol.java:861)\r\n	at org.apache.tomcat.util.net.NioEndpointTSocketProcessor.doRun(NioEndpoint.java:1455)\r\n	at org.apache.tomcat.util.net.SocketProcessorBase.run(SocketProcessorBase.java:49)\r\n	at java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1142)\r\n	at java.util.concurrent.ThreadPoolExecutorTWorker.run(ThreadPoolExecutor.java:617)\r\n	at org.apache.tomcat.util.threads.TaskThreadTWrappingRunnable.run(TaskThread.java:61)\r\n	at java.lang.Thread.run(Thread.java:745)\r\nCaused by: java.lang.NumberFormatException: For input string: \"a\"\r\n	at java.lang.NumberFormatException.forInputString(NumberFormatException.java:65)\r\n	at java.lang.Integer.parseInt(Integer.java:580)\r\n	at java.lang.Integer.parseInt(Integer.java:615)\r\n	at com.alibaba.fastjson.util.TypeUtils.castToInt(TypeUtils.java:578)\r\n	at com.alibaba.fastjson.serializer.IntegerCodec.deserialze(IntegerCodec.java:100)\r\n	at com.alibaba.fastjson.parser.deserializer.FastjsonASMDeserializer_2_UserWfConfirmRoute.deserialze(Unknown Source)\r\n	at com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.deserialze(JavaBeanDeserializer.java:208)\r\n	at com.alibaba.fastjson.parser.deserializer.ArrayListTypeFieldDeserializer.parseArray(ArrayListTypeFieldDeserializer.java:158)\r\n	at com.alibaba.fastjson.parser.deserializer.ArrayListTypeFieldDeserializer.parseField(ArrayListTypeFieldDeserializer.java:62)\r\n	at com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.parseField(JavaBeanDeserializer.java:828)\r\n	at com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.deserialze(JavaBeanDeserializer.java:630)\r\n	at com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.parseRest(JavaBeanDeserializer.java:1010)\r\n	at com.alibaba.fastjson.parser.deserializer.FastjsonASMDeserializer_1_UserExt.deserialze(Unknown Source)\r\n	at com.alibaba.fastjson.parser.deserializer.JavaBeanDeserializer.deserialze(JavaBeanDeserializer.java:208)\r\n	at com.alibaba.fastjson.parser.DefaultJSONParser.parseObject(DefaultJSONParser.java:642)\r\n	... 80 more\r\n'),(492,'业务日志','リセットパスワード',44,'com.tsrs.webedi.modular.system.controller.UserMgrController','resetPwd','2017-08-05 13:51:54','成功','アカウント=null'),(493,'業務ログ','リセットパスワード',44,'com.tsrs.webedi.modular.system.controller.UserMgrController','resetPwd','2017-08-05 22:38:42','成功','アカウント=null'),(494,'業務ログ','リセットパスワード',44,'com.tsrs.webedi.modular.system.controller.UserMgrController','resetPwd','2017-08-05 22:38:49','成功','アカウント=null');
/*!40000 ALTER TABLE `operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderconfirm`
--

DROP TABLE IF EXISTS `orderconfirm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderconfirm` (
  `order_hid` int(11) NOT NULL COMMENT '受注HID',
  `order_confirm_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '受注確認者ID',
  `order_confirm_dt` datetime NOT NULL COMMENT '受注確認日時',
  `order_confirm_remark` varchar(500) COLLATE utf8_bin NOT NULL COMMENT '受注確認備考',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`order_hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='受注確定情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderconfirm`
--

LOCK TABLES `orderconfirm` WRITE;
/*!40000 ALTER TABLE `orderconfirm` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderconfirm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderdtl`
--

DROP TABLE IF EXISTS `orderdtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderdtl` (
  `order_did` int(11) NOT NULL AUTO_INCREMENT COMMENT '受注DID',
  `order_hid` int(11) NOT NULL COMMENT '受注HID',
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`order_did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='受注DTL情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdtl`
--

LOCK TABLES `orderdtl` WRITE;
/*!40000 ALTER TABLE `orderdtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderdtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orderhdr`
--

DROP TABLE IF EXISTS `orderhdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orderhdr` (
  `order_hid` int(11) NOT NULL AUTO_INCREMENT COMMENT '受注HID',
  `order_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '受注NO',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN:削除',
  `create_dt` date NOT NULL COMMENT '作成日',
  `order_amt_without_tax` decimal(13,1) NOT NULL COMMENT '受注金額(税抜)',
  `work_start_ymd` date NOT NULL COMMENT '作業開始日',
  `work_end_ymd` date NOT NULL COMMENT '作業終了日',
  `project_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '案件番号',
  `project_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '案件名称',
  `work_content` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業内容',
  `work_place` varchar(100) COLLATE utf8_bin DEFAULT NULL COMMENT '作業場所',
  `order_content` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '注文内容',
  `special_affairs` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '特記事項',
  `remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '備考',
  `order_doc_file_id` int(11) DEFAULT NULL COMMENT '注文書',
  `est_hid` int(11) DEFAULT NULL COMMENT '見積HID',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`order_hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='受注HDR情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderhdr`
--

LOCK TABLES `orderhdr` WRITE;
/*!40000 ALTER TABLE `orderhdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `orderhdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pjclass`
--

DROP TABLE IF EXISTS `pjclass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pjclass` (
  `pj_class_cd` char(3) COLLATE utf8_bin NOT NULL COMMENT '案件分類C',
  `pj_class_nm` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '案件名称',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN：廃止',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`pj_class_cd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='案件分類';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pjclass`
--

LOCK TABLES `pjclass` WRITE;
/*!40000 ALTER TABLE `pjclass` DISABLE KEYS */;
/*!40000 ALTER TABLE `pjclass` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `program`
--

DROP TABLE IF EXISTS `program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `program` (
  `pg_id` varchar(15) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT '機能ID',
  `pg_nm` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '機能名',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN:削除',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`pg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='機能情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `program`
--

LOCK TABLES `program` WRITE;
/*!40000 ALTER TABLE `program` DISABLE KEYS */;
/*!40000 ALTER TABLE `program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ratiomgr`
--

DROP TABLE IF EXISTS `ratiomgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ratiomgr` (
  `ratio_mgr_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '料率管理ID',
  `ratio_type` char(1) COLLATE utf8_bin NOT NULL COMMENT '料率タイプ:1：健康保険\n2：厚生年金',
  `start_dt` date NOT NULL COMMENT '開始日',
  `end_dt` date NOT NULL DEFAULT '2099-12-31' COMMENT '終了日',
  `age_from` int(11) NOT NULL COMMENT '年齢From',
  `age_to` int(11) NOT NULL DEFAULT '999' COMMENT '年齢To(含まない)',
  `ratio` decimal(5,2) NOT NULL COMMENT '料率',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`ratio_mgr_id`),
  UNIQUE KEY `ratioMgr_u_atl1` (`ratio_type`,`age_from`,`age_to`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='料率管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ratiomgr`
--

LOCK TABLES `ratiomgr` WRITE;
/*!40000 ALTER TABLE `ratiomgr` DISABLE KEYS */;
/*!40000 ALTER TABLE `ratiomgr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relation`
--

DROP TABLE IF EXISTS `relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relation` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'キー',
  `menuid` int(11) DEFAULT NULL COMMENT 'メニーid',
  `roleid` int(11) DEFAULT NULL COMMENT 'ロールid',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3679 DEFAULT CHARSET=utf8 COMMENT='ロールメニー関連表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relation`
--

LOCK TABLES `relation` WRITE;
/*!40000 ALTER TABLE `relation` DISABLE KEYS */;
INSERT INTO `relation` VALUES (3377,105,5),(3378,106,5),(3379,107,5),(3380,108,5),(3381,109,5),(3382,110,5),(3383,111,5),(3384,112,5),(3385,113,5),(3386,114,5),(3387,115,5),(3388,116,5),(3389,117,5),(3390,118,5),(3391,119,5),(3392,120,5),(3393,121,5),(3394,122,5),(3395,150,5),(3396,151,5),(3624,105,1),(3625,106,1),(3626,107,1),(3627,108,1),(3628,109,1),(3629,110,1),(3630,111,1),(3631,112,1),(3632,113,1),(3633,165,1),(3634,166,1),(3635,167,1),(3636,114,1),(3637,115,1),(3638,116,1),(3639,117,1),(3640,118,1),(3641,162,1),(3642,163,1),(3643,164,1),(3644,119,1),(3645,120,1),(3646,121,1),(3647,122,1),(3648,150,1),(3649,151,1),(3650,128,1),(3651,134,1),(3652,158,1),(3653,159,1),(3654,130,1),(3655,131,1),(3656,135,1),(3657,136,1),(3658,137,1),(3659,152,1),(3660,153,1),(3661,154,1),(3662,132,1),(3663,138,1),(3664,139,1),(3665,140,1),(3666,155,1),(3667,156,1),(3668,157,1),(3669,133,1),(3670,160,1),(3671,161,1),(3672,141,1),(3673,142,1),(3674,143,1),(3675,144,1),(3676,148,1),(3677,145,1),(3678,149,1);
/*!40000 ALTER TABLE `relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `request`
--

DROP TABLE IF EXISTS `request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `request` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '請求ID',
  `req_dt` date NOT NULL COMMENT '請求日',
  `req_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '請求担当',
  `req_amt_without_tax` decimal(10,1) NOT NULL COMMENT '請求金額（税抜）:請求金額（税抜）の合計',
  `req_amt_tax` decimal(10,1) DEFAULT NULL COMMENT '消費税',
  `req_amt_with_tax` decimal(10,1) DEFAULT NULL COMMENT '請求金額（税込）',
  `req_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '請求備考',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`req_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='請求';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `request`
--

LOCK TABLES `request` WRITE;
/*!40000 ALTER TABLE `request` DISABLE KEYS */;
/*!40000 ALTER TABLE `request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requestaccepted`
--

DROP TABLE IF EXISTS `requestaccepted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requestaccepted` (
  `req_id` int(11) NOT NULL COMMENT '請求ID',
  `last_accept_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '最終承認者ID',
  `last_accept_date` datetime NOT NULL COMMENT '最終承認日時',
  `req_apply_hid` int(11) NOT NULL COMMENT '請求申請HID',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`req_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='承認済請求';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requestaccepted`
--

LOCK TABLES `requestaccepted` WRITE;
/*!40000 ALTER TABLE `requestaccepted` DISABLE KEYS */;
/*!40000 ALTER TABLE `requestaccepted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requestapplydtl`
--

DROP TABLE IF EXISTS `requestapplydtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requestapplydtl` (
  `req_apply_did` int(11) NOT NULL AUTO_INCREMENT COMMENT '請求申請DID',
  `req_apply_hid` int(11) NOT NULL COMMENT '請求申請HID',
  `display_order` int(11) NOT NULL COMMENT '表示順',
  `accept_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '承認者ID',
  `confirm_st` char(1) COLLATE utf8_bin NOT NULL COMMENT '承認状況:1：未承認\n2：承認済\n3：拒否',
  `con_rej_comment` varchar(500) COLLATE utf8_bin NOT NULL COMMENT '承認(拒否)コメント',
  `con_rej_dt` time DEFAULT NULL COMMENT '承認(拒否)日時',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`req_apply_did`),
  UNIQUE KEY `apprApplyDtl_u_1` (`req_apply_hid`,`display_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='請求申請DTL情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requestapplydtl`
--

LOCK TABLES `requestapplydtl` WRITE;
/*!40000 ALTER TABLE `requestapplydtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `requestapplydtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `requestapplyhdr`
--

DROP TABLE IF EXISTS `requestapplyhdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `requestapplyhdr` (
  `req_apply_hid` int(11) NOT NULL AUTO_INCREMENT COMMENT '請求申請HID',
  `req_id` int(11) NOT NULL COMMENT '稟議書ID',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN:削除',
  `apply_reason` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '申請理由',
  `apply_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '申請者ID',
  `apply_dt` time NOT NULL COMMENT '申請日時',
  `confirm_wait_display_order` int(11) DEFAULT NULL COMMENT '承認待表示順:承認待となっている申請DTLの表示順を設定',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`req_apply_hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='請求申請HDR情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requestapplyhdr`
--

LOCK TABLES `requestapplyhdr` WRITE;
/*!40000 ALTER TABLE `requestapplyhdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `requestapplyhdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'キーid',
  `num` int(11) DEFAULT NULL COMMENT '順番',
  `pid` int(11) DEFAULT NULL COMMENT '親ロールid',
  `name` varchar(255) DEFAULT NULL COMMENT 'ロール名称',
  `deptid` int(11) DEFAULT NULL COMMENT '部門名称',
  `tips` varchar(255) DEFAULT NULL COMMENT 'ヒント',
  `version` int(11) DEFAULT NULL COMMENT '保持フィールド',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COMMENT='ロール表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,1,0,'システム管理者',24,'administrator',1),(5,2,1,'臨時',26,'temp',NULL);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salereqrel`
--

DROP TABLE IF EXISTS `salereqrel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salereqrel` (
  `req_id` int(11) NOT NULL COMMENT '請求ID',
  `sales_id` int(11) NOT NULL COMMENT '売上ID',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`req_id`,`sales_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='売上・請求・対照表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salereqrel`
--

LOCK TABLES `salereqrel` WRITE;
/*!40000 ALTER TABLE `salereqrel` DISABLE KEYS */;
/*!40000 ALTER TABLE `salereqrel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '売上ID',
  `order_hid` int(11) NOT NULL COMMENT '受注HID',
  `order_did` int(11) NOT NULL COMMENT '受注DID',
  `appr_doc_id` int(11) NOT NULL COMMENT '稟議書ID',
  `add_up_ym` varchar(6) COLLATE utf8_bin NOT NULL COMMENT '計上年月',
  `add_up_dt` date NOT NULL COMMENT '計上日',
  `emp_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '要員区分/補助:1：新規要員\n2：既存要員\n3：要員退社',
  `emp_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '社員番号',
  `emp_nm` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '社員名',
  `emp_nm_fuli` varchar(30) COLLATE utf8_bin NOT NULL COMMENT '社員名(フリガナ)',
  `bussiness_main_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '営業主担当',
  `sales_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '売上登録備考',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`sales_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='売上';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salescostdtl`
--

DROP TABLE IF EXISTS `salescostdtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salescostdtl` (
  `sales_id` int(11) NOT NULL COMMENT '売上ID',
  `payment_dat` date DEFAULT NULL COMMENT '締日',
  `pj_nm` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業案件名称',
  `bp_comp_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社ID',
  `bp_comp_emp_nm` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '所属会社名/社員氏名',
  `bp_cost_price` decimal(10,1) DEFAULT NULL COMMENT '社保加算後単価:加入の場合、単価＋交通費＋（健康保険+厚生年金）＊1.0085\n加入しない場合、単価＋交通費',
  `bp_cost_amt_without_tax` decimal(10,1) DEFAULT NULL COMMENT '社保加算金額（税抜）:社保加算後単価＊工数（月次用）',
  `bp_cost_tax` decimal(10,1) DEFAULT NULL COMMENT '消費税',
  `bp_cost_amt_with_tax` decimal(10,1) DEFAULT NULL COMMENT '社保加算金額（税込）',
  `payment_plan_d` int(11) DEFAULT NULL COMMENT '支払サイト/出金日付の日',
  `payment_due_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '支払サイト/締日区分',
  `pay_month_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '支払サイト/支払月区分',
  `pay_plan_d` int(11) DEFAULT NULL COMMENT '支払サイト/支払日付の日',
  `salary_pay_plan_dt` date DEFAULT NULL COMMENT '出金予定日',
  `sales_cost_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '売上原価備考',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`sales_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='売上_原価明細';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salescostdtl`
--

LOCK TABLES `salescostdtl` WRITE;
/*!40000 ALTER TABLE `salescostdtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `salescostdtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salesincentivedtl`
--

DROP TABLE IF EXISTS `salesincentivedtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salesincentivedtl` (
  `sales_id` int(11) NOT NULL COMMENT '売上ID',
  `payment_dat` date DEFAULT NULL COMMENT '締日',
  `pj_nm` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業案件名称',
  `client_no` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント番号',
  `client_nm` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT 'クライアント名称',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`sales_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='売上_インセンティブ明細';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salesincentivedtl`
--

LOCK TABLES `salesincentivedtl` WRITE;
/*!40000 ALTER TABLE `salesincentivedtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `salesincentivedtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salesreqdtl`
--

DROP TABLE IF EXISTS `salesreqdtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `salesreqdtl` (
  `sales_id` int(11) NOT NULL COMMENT '売上ID',
  `payment_dat` date NOT NULL COMMENT '締日:クライアントの締日',
  `next_pj_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '次のPJ:次のPJ（売上）選択し\n1：既存\n2：経験',
  `pj_nm` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業案件名称',
  `work_content` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '作業内容・範囲',
  `work_place` varchar(200) COLLATE utf8_bin DEFAULT NULL COMMENT '勤務地/最寄駅',
  `client_no` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'クライアント番号',
  `client_nm` varchar(50) COLLATE utf8_bin NOT NULL COMMENT 'クライアント名',
  `req_start_dt` date DEFAULT NULL COMMENT '期間FROM:請求書',
  `req_end_dt` date DEFAULT NULL COMMENT '期間TO:請求書',
  `sell_price` decimal(10,1) NOT NULL COMMENT '上位単金/単価:請求書の基準単価',
  `current_mon_work_time` decimal(4,2) NOT NULL COMMENT '工数（月次用）:当月入社の場合、小数部、そのほか、１とする',
  `wh_max` decimal(4,1) DEFAULT NULL COMMENT '作業時間（上限・H）',
  `wh_min` decimal(4,1) DEFAULT NULL COMMENT '作業時間（下限・H）',
  `real_work_hour` decimal(4,1) DEFAULT NULL COMMENT '実績時間:勤怠情報から取得（単位：時間）',
  `excess_price` decimal(10,1) DEFAULT NULL COMMENT '超過単価（円）',
  `deducation_price` decimal(10,1) DEFAULT NULL COMMENT '控除単価（円）',
  `work_amt` decimal(10,1) DEFAULT NULL COMMENT '金額:工数（月次用）＊基準単価\n手動変更可能か？',
  `travel_cost` decimal(10,1) DEFAULT NULL COMMENT '交通費',
  `work_time_unit_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '作業時間単位:1:10分　2：15分　3：30分　4：1時',
  `other_cost` decimal(10,1) DEFAULT NULL COMMENT '経費/オンライン当番',
  `pay_month_k` char(1) COLLATE utf8_bin DEFAULT NULL COMMENT '支払サイト/支払月区分:1：翌月/2：翌々月/3：翌々々月',
  `pay_plan_d` int(11) DEFAULT NULL COMMENT '支払サイト/支払日付の日',
  `client_pay_dt` date DEFAULT NULL COMMENT 'お支払期日:支払月＝当月＋支払サイト/支払月区分（1：翌月/2：翌々月/3：翌々々月）\nお支払期日＝ 支払月+支払サイト/支払日付の日',
  `overwork_amt` decimal(10,1) DEFAULT NULL COMMENT '残業代:計算方法が確認要',
  `deduction_amt` decimal(10,1) DEFAULT NULL COMMENT '控除金額:計算方法が確認要\n欠勤控除？',
  `client_pay_without_tax` decimal(10,1) DEFAULT NULL COMMENT '税抜金額:基本金額＋交通費＋経費',
  `client_pay_tax` decimal(10,1) DEFAULT NULL COMMENT '消 費 税:税抜金額＊消費税',
  `client_pay_with_tax` decimal(10,1) DEFAULT NULL COMMENT '税込金額:税抜合計＋税込合計',
  `pj_class_cd` char(3) COLLATE utf8_bin DEFAULT NULL COMMENT '案件分類C',
  `gross_amt` decimal(10,1) DEFAULT NULL COMMENT '粗利額:請求の税抜金額-原価の税抜金額',
  `sales_req_remark` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '売上請求備考',
  `money_rec_plan_dt` date DEFAULT NULL COMMENT '入金予定日:手入力',
  `pay_lt` int(11) DEFAULT NULL COMMENT '支払LT:売上請求明細の入金予定日-原価明細の出金予定日',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`sales_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='売上_請求明細';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salesreqdtl`
--

LOCK TABLES `salesreqdtl` WRITE;
/*!40000 ALTER TABLE `salesreqdtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `salesreqdtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submenu`
--

DROP TABLE IF EXISTS `submenu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submenu` (
  `sub_menu_cd` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'サブメニューCD',
  `sub_menu_nam` varchar(50) COLLATE utf8_bin NOT NULL COMMENT 'サブメニュー名',
  `use_flg` char(1) COLLATE utf8_bin DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN:削除',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`sub_menu_cd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='サブメニュー情報';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submenu`
--

LOCK TABLES `submenu` WRITE;
/*!40000 ALTER TABLE `submenu` DISABLE KEYS */;
/*!40000 ALTER TABLE `submenu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submenuprogram`
--

DROP TABLE IF EXISTS `submenuprogram`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submenuprogram` (
  `sub_menu_cd` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'サブメニューCD',
  `menu_type` char(1) COLLATE utf8_bin NOT NULL COMMENT 'メニュータイプ:M:メニュー\nP：機能',
  `pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '機能ID',
  `low_sub_menu_cd` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '下位サブメニューCD',
  `display_order` int(11) NOT NULL COMMENT '表示順',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`sub_menu_cd`,`menu_type`,`pg_id`,`low_sub_menu_cd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='サブメニュー・機能対照表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submenuprogram`
--

LOCK TABLES `submenuprogram` WRITE;
/*!40000 ALTER TABLE `submenuprogram` DISABLE KEYS */;
/*!40000 ALTER TABLE `submenuprogram` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sysfilemgr`
--

DROP TABLE IF EXISTS `sysfilemgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sysfilemgr` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ファイルID',
  `file_ext` varchar(8) COLLATE utf8_bin DEFAULT NULL COMMENT '拡張子',
  `mime_type` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT 'MimeType',
  `file_nm` varchar(64) COLLATE utf8_bin DEFAULT NULL COMMENT 'オリジナルファイル名',
  `file_path` varchar(255) COLLATE utf8_bin DEFAULT NULL COMMENT '保存相対パス',
  `file_size` int(11) DEFAULT NULL COMMENT 'ファイルサイズ',
  `file_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '保存ユーザ',
  `file_ymd` datetime DEFAULT NULL COMMENT '保存日時',
  `use_flg` char(1) COLLATE utf8_bin DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN:削除',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`file_id`),
  UNIQUE KEY `sysSetting_u1` (`file_ext`,`mime_type`,`file_nm`,`file_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='ファイル管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sysfilemgr`
--

LOCK TABLES `sysfilemgr` WRITE;
/*!40000 ALTER TABLE `sysfilemgr` DISABLE KEYS */;
/*!40000 ALTER TABLE `sysfilemgr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `syssetting`
--

DROP TABLE IF EXISTS `syssetting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `syssetting` (
  `sys_setting_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '設定ID',
  `sys_cd` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT 'システムC',
  `major_class_cd` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '大分類C',
  `mid_class_cd` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '中分類C',
  `minor_class_cd` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '小分類C',
  `str_val1` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '文字列1',
  `str_val2` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '文字列2',
  `str_val3` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '文字列3',
  `str_val4` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '文字列4',
  `str_val5` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '文字列5',
  `num_val1` decimal(10,3) DEFAULT NULL COMMENT '数値1',
  `num_val2` decimal(10,3) DEFAULT NULL COMMENT '数値2',
  `num_val3` decimal(10,3) DEFAULT NULL COMMENT '数値3',
  `num_val4` decimal(10,3) DEFAULT NULL COMMENT '数値4',
  `num_val5` decimal(10,3) DEFAULT NULL COMMENT '数値5',
  `remark1` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '備考1',
  `remark2` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '備考2',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`sys_setting_id`),
  UNIQUE KEY `sysSetting_u1` (`sys_cd`,`major_class_cd`,`mid_class_cd`,`minor_class_cd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='設定';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `syssetting`
--

LOCK TABLES `syssetting` WRITE;
/*!40000 ALTER TABLE `syssetting` DISABLE KEYS */;
/*!40000 ALTER TABLE `syssetting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taxmgr`
--

DROP TABLE IF EXISTS `taxmgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taxmgr` (
  `tax_mgr_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '消費税管理ID',
  `start_dt` date NOT NULL COMMENT '開始日',
  `end_dt` date NOT NULL DEFAULT '2099-12-31' COMMENT '終了日',
  `tax_rate` decimal(5,2) NOT NULL COMMENT '消費率',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`tax_mgr_id`),
  UNIQUE KEY `taxMgr_u_atl1` (`start_dt`,`end_dt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='消費税管理';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taxmgr`
--

LOCK TABLES `taxmgr` WRITE;
/*!40000 ALTER TABLE `taxmgr` DISABLE KEYS */;
/*!40000 ALTER TABLE `taxmgr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
INSERT INTO `test` VALUES (1,'1231');
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'キーid',
  `avatar` varchar(255) DEFAULT NULL COMMENT 'アバター',
  `account` varchar(45) DEFAULT NULL COMMENT 'アカウント',
  `password` varchar(45) DEFAULT NULL COMMENT 'パスワード',
  `salt` varchar(45) DEFAULT NULL COMMENT 'パスワード塩',
  `name` varchar(45) DEFAULT NULL COMMENT '名前',
  `last_login_dt` datetime DEFAULT NULL COMMENT '生日',
  `sex` int(11) DEFAULT NULL COMMENT '性別（1：男 2：女）',
  `email` varchar(45) DEFAULT NULL COMMENT 'eメール',
  `phone` varchar(45) DEFAULT NULL COMMENT '電話番号',
  `roleid` int(11) DEFAULT NULL COMMENT 'ロールid',
  `deptid` int(11) DEFAULT NULL COMMENT '部門id',
  `status` int(11) DEFAULT NULL COMMENT '状態(1：起用  2：凍結  3：削除）',
  `createtime` datetime DEFAULT NULL COMMENT '作成時間',
  `version` int(11) DEFAULT NULL COMMENT '保持フィールド',
  `user_type` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=308 DEFAULT CHARSET=utf8 COMMENT='管理者表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'girl.gif','admin','67de2aa705297249c2e5adc27fb5ac36','gyl1e','桜木　花道','2017-08-05 19:01:15',1,'sn93@qq.com','18200000000',1,27,1,'2016-01-29 08:49:53',25,'A'),(44,NULL,'test','140dce875893f779aa281b6185bc77a0','p0088','赤木　晴子','2017-08-05 22:28:01',2,'abc@123.com','',5,26,1,'2017-05-16 20:33:37',NULL,'C'),(100,'0000000100','00000100','0000000100','0000000100','ユーザ100','2017-07-27 20:15:49',100,'0000000100','0000000100',5,26,1,'2017-07-27 20:15:49',100,'C'),(101,'0000000101','00000101','0000000101','0000000101','ユーザ101','2017-07-27 20:15:49',101,'0000000101','0000000101',5,26,1,'2017-07-27 20:15:49',101,'C'),(102,'0000000102','00000102','0000000102','0000000102','ユーザ102','2017-07-27 20:15:49',102,'0000000102','0000000102',5,26,1,'2017-07-27 20:15:49',102,'C'),(103,'0000000103','00000103','0000000103','0000000103','ユーザ103','2017-07-27 20:15:49',103,'0000000103','0000000103',5,26,1,'2017-07-27 20:15:49',103,'C'),(104,'0000000104','00000104','0000000104','0000000104','ユーザ104','2017-07-27 20:15:49',104,'0000000104','0000000104',5,26,1,'2017-07-27 20:15:49',104,'C'),(105,'0000000105','00000105','0000000105','0000000105','ユーザ105','2017-07-27 20:15:49',105,'0000000105','0000000105',5,26,1,'2017-07-27 20:15:49',105,'C'),(106,'0000000106','00000106','0000000106','0000000106','ユーザ106','2017-07-27 20:15:49',106,'0000000106','0000000106',5,26,1,'2017-07-27 20:15:49',106,'C'),(107,'0000000107','00000107','0000000107','0000000107','ユーザ107','2017-07-27 20:15:49',107,'0000000107','0000000107',5,26,1,'2017-07-27 20:15:49',107,'C'),(108,'0000000108','00000108','0000000108','0000000108','ユーザ108','2017-07-27 20:15:49',108,'0000000108','0000000108',5,26,1,'2017-07-27 20:15:49',108,'C'),(109,'0000000109','00000109','0000000109','0000000109','ユーザ109','2017-07-27 20:15:49',109,'0000000109','0000000109',5,26,1,'2017-07-27 20:15:49',109,'C'),(110,'0000000110','00000110','0000000110','0000000110','ユーザ110','2017-07-27 20:15:49',110,'0000000110','0000000110',5,26,1,'2017-07-27 20:15:49',110,'C'),(111,'0000000111','00000111','0000000111','0000000111','ユーザ111','2017-07-27 20:15:49',111,'0000000111','0000000111',5,26,1,'2017-07-27 20:15:49',111,'C'),(112,'0000000112','00000112','0000000112','0000000112','ユーザ112','2017-07-27 20:15:49',112,'0000000112','0000000112',5,26,1,'2017-07-27 20:15:49',112,'C'),(113,'0000000113','00000113','0000000113','0000000113','ユーザ113','2017-07-27 20:15:49',113,'0000000113','0000000113',5,26,1,'2017-07-27 20:15:49',113,'C'),(114,'0000000114','00000114','0000000114','0000000114','ユーザ114','2017-07-27 20:15:49',114,'0000000114','0000000114',5,26,1,'2017-07-27 20:15:49',114,'C'),(115,'0000000115','00000115','0000000115','0000000115','ユーザ115','2017-07-27 20:15:49',115,'0000000115','0000000115',5,26,1,'2017-07-27 20:15:49',115,'C'),(116,'0000000116','00000116','0000000116','0000000116','ユーザ116','2017-07-27 20:15:50',116,'0000000116','0000000116',5,26,1,'2017-07-27 20:15:50',116,'C'),(117,'0000000117','00000117','0000000117','0000000117','ユーザ117','2017-07-27 20:15:50',117,'0000000117','0000000117',5,26,1,'2017-07-27 20:15:50',117,'C'),(118,'0000000118','00000118','0000000118','0000000118','ユーザ118','2017-07-27 20:15:50',118,'0000000118','0000000118',5,26,1,'2017-07-27 20:15:50',118,'C'),(119,'0000000119','00000119','0000000119','0000000119','ユーザ119','2017-07-27 20:15:50',119,'0000000119','0000000119',5,26,1,'2017-07-27 20:15:50',119,'C'),(120,'0000000120','00000120','0000000120','0000000120','ユーザ120','2017-07-27 20:15:50',120,'0000000120','0000000120',5,26,1,'2017-07-27 20:15:50',120,'C'),(121,'0000000121','00000121','0000000121','0000000121','ユーザ121','2017-07-27 20:15:50',121,'0000000121','0000000121',5,26,1,'2017-07-27 20:15:50',121,'C'),(122,'0000000122','00000122','0000000122','0000000122','ユーザ122','2017-07-27 20:15:50',122,'0000000122','0000000122',5,26,1,'2017-07-27 20:15:50',122,'C'),(123,'0000000123','00000123','0000000123','0000000123','ユーザ123','2017-07-27 20:15:50',123,'0000000123','0000000123',5,26,1,'2017-07-27 20:15:50',123,'C'),(124,'0000000124','00000124','0000000124','0000000124','ユーザ124','2017-07-27 20:15:50',124,'0000000124','0000000124',5,26,1,'2017-07-27 20:15:50',124,'C'),(125,'0000000125','00000125','0000000125','0000000125','ユーザ125','2017-07-27 20:15:50',125,'0000000125','0000000125',5,26,1,'2017-07-27 20:15:50',125,'C'),(126,'0000000126','00000126','0000000126','0000000126','ユーザ126','2017-07-27 20:15:50',126,'0000000126','0000000126',5,26,1,'2017-07-27 20:15:50',126,'C'),(127,'0000000127','00000127','0000000127','0000000127','ユーザ127','2017-07-27 20:15:50',127,'0000000127','0000000127',5,26,1,'2017-07-27 20:15:50',127,'C'),(128,'0000000128','00000128','0000000128','0000000128','ユーザ128','2017-07-27 20:15:50',128,'0000000128','0000000128',5,26,1,'2017-07-27 20:15:50',128,'C'),(129,'0000000129','00000129','0000000129','0000000129','ユーザ129','2017-07-27 20:15:50',129,'0000000129','0000000129',5,26,1,'2017-07-27 20:15:50',129,'C'),(130,'0000000130','00000130','0000000130','0000000130','ユーザ130','2017-07-27 20:15:50',130,'0000000130','0000000130',5,26,1,'2017-07-27 20:15:50',130,'C'),(200,'00000200','00000200','0000000200','0000000200','0000000200','2017-07-27 20:29:52',200,'0000000200','0000000200',5,26,1,'2017-07-27 20:29:52',200,'C'),(201,'00000201','00000201','0000000201','0000000201','0000000201','2017-07-27 20:29:52',201,'0000000201','0000000201',5,26,1,'2017-07-27 20:29:52',201,'C'),(202,'00000202','00000202','0000000202','0000000202','0000000202','2017-07-27 20:29:52',202,'0000000202','0000000202',5,26,1,'2017-07-27 20:29:52',202,'C'),(203,'00000203','00000203','0000000203','0000000203','0000000203','2017-07-27 20:29:52',203,'0000000203','0000000203',5,26,1,'2017-07-27 20:29:52',203,'C'),(204,'00000204','00000204','0000000204','0000000204','0000000204','2017-07-27 20:29:52',204,'0000000204','0000000204',5,26,1,'2017-07-27 20:29:52',204,'C'),(205,'00000205','00000205','0000000205','0000000205','0000000205','2017-07-27 20:29:52',205,'0000000205','0000000205',5,26,1,'2017-07-27 20:29:52',205,'C'),(206,'00000206','00000206','0000000206','0000000206','0000000206','2017-07-27 20:29:52',206,'0000000206','0000000206',5,26,1,'2017-07-27 20:29:52',206,'C'),(207,'00000207','00000207','0000000207','0000000207','0000000207','2017-07-27 20:29:52',207,'0000000207','0000000207',5,26,1,'2017-07-27 20:29:52',207,'C'),(208,'00000208','00000208','0000000208','0000000208','0000000208','2017-07-27 20:29:52',208,'0000000208','0000000208',5,26,1,'2017-07-27 20:29:52',208,'C'),(209,'00000209','00000209','0000000209','0000000209','0000000209','2017-07-27 20:29:53',209,'0000000209','0000000209',5,26,1,'2017-07-27 20:29:53',209,'C'),(210,'00000210','00000210','0000000210','0000000210','0000000210','2017-07-27 20:29:53',210,'0000000210','0000000210',5,26,1,'2017-07-27 20:29:53',210,'C'),(211,'00000211','00000211','0000000211','0000000211','0000000211','2017-07-27 20:29:53',211,'0000000211','0000000211',5,26,1,'2017-07-27 20:29:53',211,'C'),(212,'00000212','00000212','0000000212','0000000212','0000000212','2017-07-27 20:29:53',212,'0000000212','0000000212',5,26,1,'2017-07-27 20:29:53',212,'C'),(213,'00000213','00000213','0000000213','0000000213','0000000213','2017-07-27 20:29:53',213,'0000000213','0000000213',5,26,1,'2017-07-27 20:29:53',213,'C'),(214,'00000214','00000214','0000000214','0000000214','0000000214','2017-07-27 20:29:53',214,'0000000214','0000000214',5,26,1,'2017-07-27 20:29:53',214,'C'),(215,'00000215','00000215','0000000215','0000000215','0000000215','2017-07-27 20:29:53',215,'0000000215','0000000215',5,26,1,'2017-07-27 20:29:53',215,'C'),(216,'00000216','00000216','0000000216','0000000216','0000000216','2017-07-27 20:29:53',216,'0000000216','0000000216',5,26,1,'2017-07-27 20:29:53',216,'C'),(217,'00000217','00000217','0000000217','0000000217','0000000217','2017-07-27 20:29:53',217,'0000000217','0000000217',5,26,1,'2017-07-27 20:29:53',217,'C'),(218,'00000218','00000218','0000000218','0000000218','0000000218','2017-07-27 20:29:53',218,'0000000218','0000000218',5,26,1,'2017-07-27 20:29:53',218,'C'),(219,'00000219','00000219','0000000219','0000000219','0000000219','2017-07-27 20:29:53',219,'0000000219','0000000219',5,26,1,'2017-07-27 20:29:53',219,'C'),(220,'00000220','00000220','0000000220','0000000220','0000000220','2017-07-27 20:29:53',220,'0000000220','0000000220',5,26,1,'2017-07-27 20:29:53',220,'C'),(221,'00000221','00000221','0000000221','0000000221','0000000221','2017-07-27 20:29:53',221,'0000000221','0000000221',5,26,1,'2017-07-27 20:29:53',221,'C'),(222,'00000222','00000222','0000000222','0000000222','0000000222','2017-07-27 20:29:53',222,'0000000222','0000000222',5,26,1,'2017-07-27 20:29:53',222,'C'),(223,'00000223','00000223','0000000223','0000000223','0000000223','2017-07-27 20:29:53',223,'0000000223','0000000223',5,26,1,'2017-07-27 20:29:53',223,'C'),(224,'00000224','00000224','0000000224','0000000224','0000000224','2017-07-27 20:29:53',224,'0000000224','0000000224',5,26,1,'2017-07-27 20:29:53',224,'C'),(225,'00000225','00000225','0000000225','0000000225','0000000225','2017-07-27 20:29:53',225,'0000000225','0000000225',5,26,1,'2017-07-27 20:29:53',225,'C'),(226,'00000226','00000226','0000000226','0000000226','0000000226','2017-07-27 20:29:53',226,'0000000226','0000000226',5,26,1,'2017-07-27 20:29:53',226,'C'),(227,'00000227','00000227','0000000227','0000000227','0000000227','2017-07-27 20:29:53',227,'0000000227','0000000227',5,26,1,'2017-07-27 20:29:53',227,'C'),(228,'00000228','00000228','0000000228','0000000228','0000000228','2017-07-27 20:29:53',228,'0000000228','0000000228',5,26,1,'2017-07-27 20:29:53',228,'C'),(229,'00000229','00000229','0000000229','0000000229','0000000229','2017-07-27 20:29:53',229,'0000000229','0000000229',5,26,1,'2017-07-27 20:29:53',229,'C'),(230,'00000230','00000230','0000000230','0000000230','0000000230','2017-07-27 20:29:53',230,'0000000230','0000000230',5,26,1,'2017-07-27 20:29:53',230,'C'),(231,'00000231','00000231','0000000231','0000000231','0000000231','2017-07-27 20:29:53',231,'0000000231','0000000231',5,26,1,'2017-07-27 20:29:53',231,'C'),(232,'00000232','00000232','0000000232','0000000232','0000000232','2017-07-27 20:29:53',232,'0000000232','0000000232',5,26,1,'2017-07-27 20:29:53',232,'C'),(233,'00000233','00000233','0000000233','0000000233','0000000233','2017-07-27 20:29:53',233,'0000000233','0000000233',5,26,1,'2017-07-27 20:29:53',233,'C'),(234,'00000234','00000234','0000000234','0000000234','0000000234','2017-07-27 20:29:53',234,'0000000234','0000000234',5,26,1,'2017-07-27 20:29:53',234,'C'),(235,'00000235','00000235','0000000235','0000000235','0000000235','2017-07-27 20:29:53',235,'0000000235','0000000235',5,26,1,'2017-07-27 20:29:53',235,'C'),(236,'00000236','00000236','0000000236','0000000236','0000000236','2017-07-27 20:29:53',236,'0000000236','0000000236',5,26,1,'2017-07-27 20:29:53',236,'C'),(237,'00000237','00000237','0000000237','0000000237','0000000237','2017-07-27 20:29:53',237,'0000000237','0000000237',5,26,1,'2017-07-27 20:29:53',237,'C'),(238,'00000238','00000238','0000000238','0000000238','0000000238','2017-07-27 20:29:53',238,'0000000238','0000000238',5,26,1,'2017-07-27 20:29:53',238,'C'),(239,'00000239','00000239','0000000239','0000000239','0000000239','2017-07-27 20:29:53',239,'0000000239','0000000239',5,26,1,'2017-07-27 20:29:53',239,'C'),(240,'00000240','00000240','0000000240','0000000240','0000000240','2017-07-27 20:29:53',240,'0000000240','0000000240',5,26,1,'2017-07-27 20:29:53',240,'C'),(241,'00000241','00000241','0000000241','0000000241','0000000241','2017-07-27 20:29:53',241,'0000000241','0000000241',5,26,1,'2017-07-27 20:29:53',241,'C'),(242,'00000242','00000242','0000000242','0000000242','0000000242','2017-07-27 20:29:53',242,'0000000242','0000000242',5,26,1,'2017-07-27 20:29:53',242,'C'),(243,'00000243','00000243','0000000243','0000000243','0000000243','2017-07-27 20:29:54',243,'0000000243','0000000243',5,26,1,'2017-07-27 20:29:54',243,'C'),(244,'00000244','00000244','0000000244','0000000244','0000000244','2017-07-27 20:29:54',244,'0000000244','0000000244',5,26,1,'2017-07-27 20:29:54',244,'C'),(245,'00000245','00000245','0000000245','0000000245','0000000245','2017-07-27 20:29:54',245,'0000000245','0000000245',5,26,1,'2017-07-27 20:29:54',245,'C'),(246,'00000246','00000246','0000000246','0000000246','0000000246','2017-07-27 20:29:54',246,'0000000246','0000000246',5,26,1,'2017-07-27 20:29:54',246,'C'),(247,'00000247','00000247','0000000247','0000000247','0000000247','2017-07-27 20:29:54',247,'0000000247','0000000247',5,26,1,'2017-07-27 20:29:54',247,'C'),(248,'00000248','00000248','0000000248','0000000248','0000000248','2017-07-27 20:29:54',248,'0000000248','0000000248',5,26,1,'2017-07-27 20:29:54',248,'C'),(249,'00000249','00000249','0000000249','0000000249','0000000249','2017-07-27 20:29:54',249,'0000000249','0000000249',5,26,1,'2017-07-27 20:29:54',249,'C'),(250,'00000250','00000250','0000000250','0000000250','0000000250','2017-07-27 20:29:54',250,'0000000250','0000000250',5,26,1,'2017-07-27 20:29:54',250,'C'),(251,'00000251','00000251','0000000251','0000000251','0000000251','2017-07-27 20:29:54',251,'0000000251','0000000251',5,26,1,'2017-07-27 20:29:54',251,'C'),(252,'00000252','00000252','0000000252','0000000252','0000000252','2017-07-27 20:29:54',252,'0000000252','0000000252',5,26,1,'2017-07-27 20:29:54',252,'C'),(253,'00000253','00000253','0000000253','0000000253','0000000253','2017-07-27 20:29:54',253,'0000000253','0000000253',5,26,1,'2017-07-27 20:29:54',253,'C'),(254,'00000254','00000254','0000000254','0000000254','0000000254','2017-07-27 20:29:54',254,'0000000254','0000000254',5,26,1,'2017-07-27 20:29:54',254,'C'),(255,'00000255','00000255','0000000255','0000000255','0000000255','2017-07-27 20:29:54',255,'0000000255','0000000255',5,26,1,'2017-07-27 20:29:54',255,'C'),(256,'00000256','00000256','0000000256','0000000256','0000000256','2017-07-27 20:29:54',256,'0000000256','0000000256',5,26,1,'2017-07-27 20:29:54',256,'C'),(257,'00000257','00000257','0000000257','0000000257','0000000257','2017-07-27 20:29:54',257,'0000000257','0000000257',5,26,1,'2017-07-27 20:29:54',257,'C'),(258,'00000258','00000258','0000000258','0000000258','0000000258','2017-07-27 20:29:54',258,'0000000258','0000000258',5,26,1,'2017-07-27 20:29:54',258,'C'),(259,'00000259','00000259','0000000259','0000000259','0000000259','2017-07-27 20:29:54',259,'0000000259','0000000259',5,26,1,'2017-07-27 20:29:54',259,'C'),(260,'00000260','00000260','0000000260','0000000260','0000000260','2017-07-27 20:29:54',260,'0000000260','0000000260',5,26,1,'2017-07-27 20:29:54',260,'C'),(261,'00000261','00000261','0000000261','0000000261','0000000261','2017-07-27 20:29:54',261,'0000000261','0000000261',5,26,1,'2017-07-27 20:29:54',261,'C'),(262,'00000262','00000262','0000000262','0000000262','0000000262','2017-07-27 20:29:54',262,'0000000262','0000000262',5,26,1,'2017-07-27 20:29:54',262,'C'),(263,'00000263','00000263','0000000263','0000000263','0000000263','2017-07-27 20:29:54',263,'0000000263','0000000263',5,26,1,'2017-07-27 20:29:54',263,'C'),(264,'00000264','00000264','0000000264','0000000264','0000000264','2017-07-27 20:29:54',264,'0000000264','0000000264',5,26,1,'2017-07-27 20:29:54',264,'C'),(265,'00000265','00000265','0000000265','0000000265','0000000265','2017-07-27 20:29:54',265,'0000000265','0000000265',5,26,1,'2017-07-27 20:29:54',265,'C'),(266,'00000266','00000266','0000000266','0000000266','0000000266','2017-07-27 20:29:54',266,'0000000266','0000000266',5,26,1,'2017-07-27 20:29:54',266,'C'),(267,'00000267','00000267','0000000267','0000000267','0000000267','2017-07-27 20:29:54',267,'0000000267','0000000267',5,26,1,'2017-07-27 20:29:54',267,'C'),(268,'00000268','00000268','0000000268','0000000268','0000000268','2017-07-27 20:29:54',268,'0000000268','0000000268',5,26,1,'2017-07-27 20:29:54',268,'C'),(269,'00000269','00000269','0000000269','0000000269','0000000269','2017-07-27 20:29:54',269,'0000000269','0000000269',5,26,1,'2017-07-27 20:29:54',269,'C'),(270,'00000270','00000270','0000000270','0000000270','0000000270','2017-07-27 20:29:54',270,'0000000270','0000000270',5,26,1,'2017-07-27 20:29:54',270,'C'),(271,'00000271','00000271','0000000271','0000000271','0000000271','2017-07-27 20:29:54',271,'0000000271','0000000271',5,26,1,'2017-07-27 20:29:54',271,'C'),(272,'00000272','00000272','0000000272','0000000272','0000000272','2017-07-27 20:29:54',272,'0000000272','0000000272',5,26,1,'2017-07-27 20:29:54',272,'C'),(273,'00000273','00000273','0000000273','0000000273','0000000273','2017-07-27 20:29:54',273,'0000000273','0000000273',5,26,1,'2017-07-27 20:29:54',273,'C'),(274,'00000274','00000274','0000000274','0000000274','0000000274','2017-07-27 20:29:54',274,'0000000274','0000000274',5,26,1,'2017-07-27 20:29:54',274,'C'),(275,'00000275','00000275','0000000275','0000000275','0000000275','2017-07-27 20:29:54',275,'0000000275','0000000275',5,26,1,'2017-07-27 20:29:54',275,'C'),(276,'00000276','00000276','0000000276','0000000276','0000000276','2017-07-27 20:29:54',276,'0000000276','0000000276',5,26,1,'2017-07-27 20:29:54',276,'C'),(277,'00000277','00000277','0000000277','0000000277','0000000277','2017-07-27 20:29:54',277,'0000000277','0000000277',5,26,1,'2017-07-27 20:29:54',277,'C'),(278,'00000278','00000278','0000000278','0000000278','0000000278','2017-07-27 20:29:55',278,'0000000278','0000000278',5,26,1,'2017-07-27 20:29:55',278,'C'),(279,'00000279','00000279','0000000279','0000000279','0000000279','2017-07-27 20:29:55',279,'0000000279','0000000279',5,26,1,'2017-07-27 20:29:55',279,'C'),(280,'00000280','00000280','0000000280','0000000280','0000000280','2017-07-27 20:29:55',280,'0000000280','0000000280',5,26,1,'2017-07-27 20:29:55',280,'C'),(281,'00000281','00000281','0000000281','0000000281','0000000281','2017-07-27 20:29:55',281,'0000000281','0000000281',5,26,1,'2017-07-27 20:29:55',281,'C'),(282,'00000282','00000282','0000000282','0000000282','0000000282','2017-07-27 20:29:55',282,'0000000282','0000000282',5,26,1,'2017-07-27 20:29:55',282,'C'),(283,'00000283','00000283','0000000283','0000000283','0000000283','2017-07-27 20:29:55',283,'0000000283','0000000283',5,26,1,'2017-07-27 20:29:55',283,'C'),(284,'00000284','00000284','0000000284','0000000284','0000000284','2017-07-27 20:29:55',284,'0000000284','0000000284',5,26,1,'2017-07-27 20:29:55',284,'C'),(285,'00000285','00000285','0000000285','0000000285','0000000285','2017-07-27 20:29:55',285,'0000000285','0000000285',5,26,1,'2017-07-27 20:29:55',285,'C'),(286,'00000286','00000286','0000000286','0000000286','0000000286','2017-07-27 20:29:55',286,'0000000286','0000000286',5,26,1,'2017-07-27 20:29:55',286,'C'),(287,'00000287','00000287','0000000287','0000000287','0000000287','2017-07-27 20:29:55',287,'0000000287','0000000287',5,26,1,'2017-07-27 20:29:55',287,'C'),(288,'00000288','00000288','0000000288','0000000288','0000000288','2017-07-27 20:29:55',288,'0000000288','0000000288',5,26,1,'2017-07-27 20:29:55',288,'C'),(289,'00000289','00000289','0000000289','0000000289','0000000289','2017-07-27 20:29:55',289,'0000000289','0000000289',5,26,1,'2017-07-27 20:29:55',289,'C'),(290,'00000290','00000290','0000000290','0000000290','0000000290','2017-07-27 20:29:55',290,'0000000290','0000000290',5,26,1,'2017-07-27 20:29:55',290,'C'),(291,'00000291','00000291','0000000291','0000000291','0000000291','2017-07-27 20:29:55',291,'0000000291','0000000291',5,26,1,'2017-07-27 20:29:55',291,'C'),(292,'00000292','00000292','0000000292','0000000292','0000000292','2017-07-27 20:29:55',292,'0000000292','0000000292',5,26,1,'2017-07-27 20:29:55',292,'C'),(293,'00000293','00000293','0000000293','0000000293','0000000293','2017-07-27 20:29:55',293,'0000000293','0000000293',5,26,1,'2017-07-27 20:29:55',293,'C'),(294,'00000294','00000294','0000000294','0000000294','0000000294','2017-07-27 20:29:55',294,'0000000294','0000000294',5,26,1,'2017-07-27 20:29:55',294,'C'),(295,'00000295','00000295','0000000295','0000000295','0000000295','2017-07-27 20:29:55',295,'0000000295','0000000295',5,26,1,'2017-07-27 20:29:55',295,'C'),(296,'00000296','00000296','0000000296','0000000296','0000000296','2017-07-27 20:29:55',296,'0000000296','0000000296',5,26,1,'2017-07-27 20:29:55',296,'C'),(297,'00000297','00000297','0000000297','0000000297','0000000297','2017-07-27 20:29:55',297,'0000000297','0000000297',5,26,1,'2017-07-27 20:29:55',297,'C'),(298,'00000298','00000298','0000000298','0000000298','0000000298','2017-07-27 20:29:55',298,'0000000298','0000000298',5,26,1,'2017-07-27 20:29:55',298,'C'),(299,'00000299','00000299','0000000299','0000000299','0000000299','2017-07-27 20:29:55',299,'0000000299','0000000299',5,26,1,'2017-07-27 20:29:55',299,'C'),(300,'00000300','00000300','0000000300','0000000300','0000000300','2017-07-27 20:29:55',300,'0000000300','0000000300',5,26,1,'2017-07-27 20:29:55',300,'C'),(301,NULL,'00000001','28da612246a0ce9c6d365569a1f0a413','7td3f','ユーザー名',NULL,NULL,NULL,NULL,1,25,1,'2017-07-27 21:53:20',NULL,'C'),(302,NULL,'00000002','d5ea59b0651d418a7e286ea3c29ee562','c3t2f','ユーザー名',NULL,NULL,NULL,NULL,1,26,1,'2017-07-27 22:08:12',NULL,'C'),(303,NULL,'00000003','9ecbb1a5fa56e9177bc883b440f91b1c','nfcxu','ユーザー名',NULL,NULL,NULL,NULL,5,26,1,'2017-07-27 22:21:43',NULL,'C'),(304,NULL,'00000006','fa614b2f97c6b0761b633d3b067e4aff','thh9r','ーザー名',NULL,NULL,NULL,NULL,1,26,1,'2017-07-27 22:45:18',NULL,'A'),(305,NULL,'99999999','242a721ee5e619ae9a3d5aa34bedc138','2h1b9','ユーザー名2','2017-07-29 21:04:08',NULL,NULL,NULL,1,26,1,'2017-07-29 20:35:13',NULL,'C'),(306,NULL,'12345678','739998c4dd01c87eff080e8e12078bb7','9zntg','ユーザ',NULL,NULL,NULL,NULL,1,26,1,'2017-07-30 14:26:20',NULL,'C'),(307,NULL,'00000000','4f72be9b3c0a0acc86e5698782c187ca','12wzp','ユーザー名',NULL,NULL,NULL,NULL,1,26,1,'2017-08-05 22:32:30',NULL,'C');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userwfconfirmroute`
--

DROP TABLE IF EXISTS `userwfconfirmroute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userwfconfirmroute` (
  `user_wf_confirm_route_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ユーザーWF承認経路ID',
  `user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'ユーザーID',
  `accept_user_id` char(10) COLLATE utf8_bin NOT NULL COMMENT '承認者ID',
  `display_order` int(11) NOT NULL COMMENT '表示順',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`user_wf_confirm_route_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='ユーザーWF承認経路';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userwfconfirmroute`
--

LOCK TABLES `userwfconfirmroute` WRITE;
/*!40000 ALTER TABLE `userwfconfirmroute` DISABLE KEYS */;
INSERT INTO `userwfconfirmroute` VALUES (1,'00000000','admin',1,'test','2017-08-05 22:38:03','US001','test','2017-08-05 22:38:03','US001'),(2,'00000000','test',2,'test','2017-08-05 22:38:03','US001','test','2017-08-05 22:38:03','US001'),(3,'00000000','00000100',3,'test','2017-08-05 22:38:03','US001','test','2017-08-05 22:38:03','US001');
/*!40000 ALTER TABLE `userwfconfirmroute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workcontent`
--

DROP TABLE IF EXISTS `workcontent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workcontent` (
  `work_content_cd` char(3) COLLATE utf8_bin NOT NULL COMMENT '作業内容C',
  `work_content_nm` varchar(50) COLLATE utf8_bin NOT NULL COMMENT '作業内容名称',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:使用\nN：廃止',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`work_content_cd`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='作業内容';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workcontent`
--

LOCK TABLES `workcontent` WRITE;
/*!40000 ALTER TABLE `workcontent` DISABLE KEYS */;
/*!40000 ALTER TABLE `workcontent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workhourdtl`
--

DROP TABLE IF EXISTS `workhourdtl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workhourdtl` (
  `wh_did` int(11) NOT NULL AUTO_INCREMENT COMMENT '勤怠管理DID',
  `wh_hid` int(11) NOT NULL COMMENT '勤怠管理HID',
  `ymd` date NOT NULL COMMENT '年月日',
  `wh_k` char(1) COLLATE utf8_bin NOT NULL COMMENT '勤怠区分:1:出勤\n2:有休\n3:休日\n4:休暇\n5:代休\n6:欠勤',
  `work_content_cd` varchar(3) COLLATE utf8_bin DEFAULT NULL COMMENT '作業内容C:出勤の場合、必須',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`wh_did`),
  KEY `calendar_i_1` (`wh_hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='勤怠管理DTL';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workhourdtl`
--

LOCK TABLES `workhourdtl` WRITE;
/*!40000 ALTER TABLE `workhourdtl` DISABLE KEYS */;
/*!40000 ALTER TABLE `workhourdtl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workhourhdr`
--

DROP TABLE IF EXISTS `workhourhdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workhourhdr` (
  `wh_hid` int(11) NOT NULL AUTO_INCREMENT COMMENT '勤怠管理HID',
  `user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT 'ユーザーID',
  `ym` date NOT NULL COMMENT '年月',
  `use_flg` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'Y' COMMENT '使用FLG:Y:有効\nN：削除',
  `sys_ins_user_id` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '登録者',
  `sys_ins_dt` datetime NOT NULL COMMENT '登録日時',
  `sys_ins_pg_id` varchar(15) COLLATE utf8_bin NOT NULL COMMENT '登録機能ID',
  `sys_upd_user_id` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT '更新者',
  `sys_upd_dt` datetime DEFAULT NULL COMMENT '更新日時',
  `sys_upd_pg_id` varchar(15) COLLATE utf8_bin DEFAULT NULL COMMENT '更新機能ID',
  PRIMARY KEY (`wh_hid`),
  KEY `calendar_i_1` (`ym`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='勤怠管理HDR';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workhourhdr`
--

LOCK TABLES `workhourhdr` WRITE;
/*!40000 ALTER TABLE `workhourhdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `workhourhdr` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-08-05 22:49:52
